# Local-First Holistic RimWorld Agent — Modification Specification

**Status:** Proposed implementation specification  
**Target:** A user-owned fork of `zorrobyte/rimagent`, preserving RimBridge and Steward  
**Baseline reviewed:** BVRimAgent revision `d615c2f`; upstream RimAgent `85cb050` (with architecture compared to the previously documented `f4429ee` snapshot)  
**Primary objective:** Play complete RimWorld colonies efficiently through an API, using deterministic automation and a cheap/local selector for routine play, a stronger model only for high-value strategic work, and reviewable flat files for plans, decision matrices, knowledge, evidence, and self-improvement.

---

## 1. Executive decision

Modify RimAgent into a three-tier control system:

1. **Tier 0 — deterministic control:** RimBridge, Steward, standing orders, validators, arithmetic, resource locks, workflow cursors, emergency reflexes, and outcome verification. This tier runs without a model.
2. **Tier 1 — cheap/local tactical selector:** Jev, a local Laya deployment, or another compatible endpoint selects one option from a small validated decision matrix. It controls routine colony policy and workflow progression without receiving arbitrary game-write authority.
3. **Tier 2 — strategic planner/reviewer:** A stronger model creates and repairs long-horizon plans, resolves novel situations, diagnoses repeated failures, and proposes refactors to plans, workflows, matrices, thresholds, and lessons. It is event-driven and used sparingly.

The local dispatcher remains the **only game writer**. Models return typed intent; they never issue unrestricted RPCs, coordinates, Python, or source edits directly.

This distinction is essential for efficiency and reliability:

- Pawn job selection, work priorities, hauling, firefighting, rescue, basic combat rally behavior, stock replenishment, and other high-frequency behavior belong in Steward or deterministic orders.
- Jev is documented as a judgment service (`Choice`, `Score`, and yes/no probability), not a tool-calling agent. It should select from legal options such as `RAISE_RICE_TARGET`, `ADVANCE_BUILD_PHASE`, or `KEEP_CURRENT_POSTURE`; code maps that selection to a bounded workflow.
- A local Laya endpoint may serve Tier 1 if an adapter can make it satisfy the same bounded-choice contract. If it can also produce valid strategic plans, it may separately be configured for Tier 2, but role contracts remain independent.
- Strong-model calls should be reserved for initial planning, material state changes, unresolved novelty, repeated failure, and offline policy review—not every pawn action or scheduled wake.

---

## 2. Goals and non-goals

### 2.1 Goals

The modified system shall:

- Play a colony from map selection or landing through stable midgame and an operator-selected endgame.
- Coordinate food, shelter, mood, labor, logistics, health, power, temperature, research, production, defense, wealth, trade, recruitment, animals, caravans, quests, and endgame preparation as one resource-constrained plan.
- Preserve fast deterministic reactions while improving strategic decisions over time.
- Use local or low-cost inference for most model-mediated decisions.
- Store authoritative knowledge, plans, matrices, policy, lessons, and traces in human-readable flat files.
- Recover after process restart without losing task state, reservations, pending verification, or plan lineage.
- Explain what the colony is trying to achieve, why a task has attention, what options were available, what action was dispatched, and whether it worked.
- Improve reusable behavior through evidence-backed proposals, regression fixtures, matched trials, promotion, and rollback.
- Remain provider-neutral: game logic must not branch on `jev`, `laya`, `qwen`, or a vendor name.

### 2.2 Non-goals

The first implementation shall not:

- Ask a model to choose every pawn job, every tick, or every hauling destination.
- Execute free-form model text.
- Let a selector invent game object IDs, coordinates, quantities, RPC names, predicates, or code.
- Hot-edit active policy during a scored episode.
- Treat an endpoint confidence value as a calibrated probability of game success.
- Treat the guide, a model explanation, or one successful colony as proven policy.
- Optimize a single scalar score at the expense of survival, deaths, or hidden intervention.
- Require a distributed multi-agent service. One Python process with durable files and one game-write dispatcher is sufficient.

---

## 3. Findings from the current repositories

### 3.1 What should be retained from RimAgent

The upstream implementation already supplies valuable infrastructure:

- RimBridge loopback HTTP access to structured state, events, map views, UI verbs, dialogs, definitions, and reflective engine reads.
- Change-first observations: tracked trends, world diffs, `state.base`, alerts, letters, dialogs, and compact pawn summaries.
- An event-driven runner with scheduled wakes, urgent interrupts, game-speed control, autosaves, episodes, and recovery.
- Steward automation for pawn work priorities, stock jobs, research queueing, and standing orders.
- A tool registry, bridge-generated tools, dashboard event bus, score history, and knowledge search.
- Flat-file skills, notebook, journal, tools, and watchers.
- Per-call capture and useful operational telemetry.

These are foundations, not replacements for the requested planning framework.

### 3.2 Gaps to close

The current RimAgent play loop is a fresh free-form tool conversation at each wake. Its optional manager emits a few prose priorities and directives, then specialist streams may write to the same live colony concurrently. The current system does not provide:

- a durable plan/goal/task graph;
- explicit maintenance goals and cross-domain resource reservations;
- a scheduler that remembers blocked, awaiting, overdue, and suspended work;
- one canonical matrix definition shared across providers;
- strict separation between selecting intent and dispatching actions;
- complete outcome verification and causal lineage;
- evidence-scoped lessons with applicability and counterevidence;
- frozen policy snapshots, proposal staging, matched promotion trials, or held-out isolation;
- holistic coverage beyond the existing five-domain examples;
- atomic ownership for concurrent specialist writes.

The current improvement stream can rewrite live brain files during play. That is useful for exploration, but it is not sufficient evidence that behavior improved and can create policy drift during evaluation.

### 3.3 Required compatibility posture

- Preserve the current free-form `think` loop as a **legacy baseline** and optional operator recovery mode.
- Disable direct concurrent game writes from the four experimental specialist streams when the framework controller is active.
- Reuse the situation packet’s observation sources, but replace “send everything to a model” with task-specific feature packets.
- Preserve the existing OpenAI-compatible client behind a provider adapter.
- Avoid RimBridge changes until a required observation or action cannot be implemented through current RPCs. Changes to the generic bridge belong upstream in RimBridge; RimAgent-specific deterministic policy belongs in Steward or the Python framework.

---

## 4. System architecture

```text
RimWorld + RimBridge
        │ events, state, RPC results
        ▼
Observation reconciler ──► derived features and forecasts
        │                         │
        │                         └── flat-file observation/trace log
        ▼
Goal/task store ◄──── Strategic Planner (strong, sparse calls)
        │                       │
        │                       └── plan/repair/proposal only
        ▼
Attention scheduler + resource arbiter
        │ focused task
        ▼
Candidate generator + hard validator (deterministic)
        │ ≤4 productive options + CONTINUE + ESCALATE
        ▼
Decision route
  ├─ deterministic rule (no judgment needed)
  ├─ cheap/local selector (Jev/Laya-compatible)
  └─ planner escalation (novel/blocked strategic case)
        │ typed option ID
        ▼
Single dispatcher ──► Steward policy / bounded RimBridge workflow
        │
        ▼
Outcome monitor and verifier
  ├─ update task/goal/plan
  ├─ release reservations
  ├─ append immutable evidence
  └─ create failure packet / lesson candidate

Offline or low-frequency review:
evidence cluster ──► strong reviewer ──► staged policy proposal
                  ──► fixtures + matched trials ──► approve/promote/rollback
```

### 4.1 Authority boundaries

| Component | May read game | May choose policy | May write game | May change active policy |
|---|---:|---:|---:|---:|
| RimBridge | Yes | No | Executes validated RPC | No |
| Steward/standing orders | Yes | Fixed deterministic policy | Yes | No |
| Observation/feature code | Yes | No | No | No |
| Attention scheduler | Derived state | Chooses task by published rules | No | No |
| Cheap selector | Relevant packet only | One offered option | No | No |
| Strategic planner | Relevant planning packet | Proposes plans/tasks | No | No |
| Dispatcher | Fresh local state | No | Yes, allowlisted | No |
| Reviewer | Saved evidence | Proposes policy diff | No | No |
| Evaluator/promoter | Recorded runs | Applies declared gates | No | Atomic activation only |
| Human operator | Full review surfaces | Yes | Through controlled override | Yes |

### 4.2 Single-writer invariant

All state-changing actions pass through one dispatcher queue. Every write requires:

- an `action_intent_id` and idempotency key;
- active plan, task, matrix, policy, observation, and endpoint revisions;
- current ownership of required resource locks;
- fresh preconditions and a still-legal bound target;
- an allowlisted action template;
- a bounded write count and stop condition;
- a verification schedule.

Concurrent planners, reviewers, observers, or selectors may run, but cannot bypass this queue. Results created against stale revisions are discarded.

---

## 5. Model roles and routing

### 5.1 Exactly two configured model roles

Keep two provider-neutral roles:

- **`planner`** — supports `PLAN`, `REPAIR`, and `REVIEW_POLICY` operations. This is normally the stronger endpoint.
- **`decision_selector`** — supports `SELECT` over a closed candidate set. This is normally Jev, local Laya, or a small local model.

The same physical endpoint may fill both roles, but each role has separate limits, prompts, capability tests, and revisioned configuration.

### 5.2 Tier 0: deterministic routing

Use no model when:

- only one productive legal option remains;
- a task is a pure observation or verification step;
- a desired state already holds;
- a standing order owns the immediate reflex;
- a fixed emergency invariant applies;
- an awaiting task is not yet due for review;
- a known safe fallback is configured after selector timeout;
- arithmetic or game legality determines the answer.

Examples: rescue a bleeding pawn through the enabled rescue order; do not reissue an existing valid bill; verify a room before marking shelter complete; sleep until the next deadline when nothing is due.

### 5.3 Tier 1: cheap/local selector

Invoke the selector only after code has:

1. selected one focused task;
2. refreshed required observations;
3. calculated demand, deadlines, pathing, distances, labor and material budgets;
4. generated concrete candidates bound to real IDs;
5. removed illegal or infeasible candidates;
6. added `CONTINUE` and `ESCALATE`;
7. reduced the packet to facts relevant to the matrix.

The selector returns exactly one offered option ID or a typed abstention/failure. The reviewed repositories contain no Laya protocol or deployment documentation, so this specification treats “Laya” as the requested local endpoint class rather than assuming a specific product API. Its adapter must be selected only after its real request/response contract is documented and passes capability tests. A Laya adapter may use structured JSON; a Jev adapter compiles the matrix into its fixed-choice API. Neither provider controls execution.

### 5.4 Tier 2: strong planner/reviewer triggers

Call the planner only on one of these triggers:

- episode initialization or adoption of an existing save;
- human objective or constraint change;
- invalidated plan assumption;
- new colonist, death, permanent incapacity, or major skill/capacity change;
- biome, season, technology, or threat-profile transition that changes feasibility;
- goal infeasibility, capability gap, or unresolved cross-domain conflict;
- repeated failure cluster exceeding policy thresholds;
- a novel incident for which no enabled matrix applies;
- milestone completion requiring selection of the next strategic horizon;
- scheduled strategic review, initially once per game day and later adaptive;
- end-of-episode review or an explicit experiment review.

A normal blocked action, stale observation, or transient RPC error should be handled locally before escalation.

### 5.5 Budget policy

Track per-role:

- calls per game day and episode;
- input/output tokens when reported;
- estimated and actual cost when known;
- p50/p95 wall latency;
- game ticks elapsed while waiting;
- fallback and escalation frequency;
- stale response rate;
- useful-plan and valid-selection rates.

Initial configurable budgets:

```yaml
budgets:
  planner:
    max_calls_per_game_day: 2
    max_calls_per_episode: 40
    max_repair_attempts_per_operation: 1
  decision_selector:
    max_calls_per_attention_turn: 1
    max_calls_per_game_hour: 4
  deterministic_first: true
  on_budget_exhausted:
    selector: rules_fallback
    planner: continue_valid_plan_or_pause_if_required
```

Budgets are guardrails to test, not claims of optimal values.

---

## 6. Provider contracts

### 6.1 Planner request and result

`PlanRequest` contains:

- operation and request ID;
- human objective and constraints;
- colony phase and planning horizon;
- maintenance vector and active incidents;
- relevant observations and their freshness;
- current plan/goal/task revisions;
- capability, predicate, workflow, and task-template catalogs;
- applicable lesson summaries with counterevidence;
- available resource envelopes;
- allowed change scope and output budget.

`PlanProposal` contains:

- assumptions and missing facts;
- strategy and alternatives;
- goals and measurable predicates;
- task/workflow references and acyclic dependencies;
- deadlines, resource envelopes, and replan triggers;
- proposal rationale as a concise claim, not hidden reasoning;
- explicit inability or observation requests where appropriate.

Local validation rejects unknown IDs, cycles, unsupported actions, missing verification, conflicting reservations, unbounded work, and attempts to modify protected policy.

### 6.2 Selector request and result

`DecisionRequest` contains:

- request/episode/task/observation/matrix/config revisions;
- one task intent;
- concise named facts and derived buckets;
- hard constraints already evaluated;
- exact offered option IDs and descriptions;
- option-specific predicted cost, risk, time, and expected effect;
- deadline and output schema.

`DecisionResult` contains:

```json
{
  "request_id": "decision.food.0042",
  "option_id": "FORAGE_SAFE",
  "status": "selected",
  "confidence": null,
  "probabilities": null,
  "rationale": "optional concise text",
  "provider_metadata": {}
}
```

Confidence remains nullable and provider-specific. Execution gates use endpoint/matrix-specific calibration, not a universal threshold.

### 6.3 Required adapters

Initial adapter registry:

- `openai_chat_completions`;
- `typesafe_systemone` for Jev;
- `local_structured_http` for Laya or another local service;
- `stub_planner` and `stub_selector` for deterministic tests.

An adapter owns transport, authentication, serialization, retries, cancellation, response parsing, and identity metadata. It may not alter matrix semantics or candidate IDs.

### 6.4 Capability tests

Connection tests perform no game writes and verify:

- schema-valid operation output;
- offered-option enforcement;
- explicit abstention/refusal behavior;
- malformed/truncated response handling;
- timeout and rate-limit behavior;
- absent confidence handling;
- request correlation and stale-result rejection;
- independent replacement of either endpoint.

---

## 7. Flat-file persistence model

Flat files are authoritative. In-memory objects are caches rebuilt from files after restart.

### 7.1 Proposed layout in the RimAgent fork

```text
brain/
  policy/
    registry.yaml
    accepted/
      objectives.yaml
      maintenance.yaml
      task-templates.yaml
      workflows.yaml
      decision-matrices.yaml
      attention.yaml
      resource-budgets.yaml
      research-priorities.yaml
      building-strategy.yaml
      routing.yaml
    proposals/<proposal-id>/...
    snapshots/<policy-revision>/manifest.yaml
  plans/
    active/<episode-id>.yaml
    archive/<episode-id>/<plan-revision>.yaml
  knowledge/
    rules/<domain>/*.yaml
    lessons/ledger.jsonl
    lessons/snapshots/<revision>.yaml
    skills/*.md
  state/
    episode.json
    goals.jsonl
    tasks.jsonl
    reservations.json
    pending-actions.json
    workflow-cursors.json
  memory/
    notebook.md
    journal.md
    operator.md
runs/
  <episode-id>/
    manifest.yaml
    observations.jsonl
    attention.jsonl
    decisions.jsonl
    actions.jsonl
    outcomes.jsonl
    failures.jsonl
    metrics.jsonl
    endpoint-traffic.jsonl
    final-report.yaml
  evaluations/...
```

### 7.2 File rules

- YAML stores human-edited policy, plans, workflows, matrices, and snapshots.
- JSONL stores append-only events, evidence, decisions, outcomes, and lessons.
- Stable IDs are referenced instead of labels or file order.
- Every record carries schema version, object revision, creation time, episode, and source/provenance.
- Writes use temporary file + flush + atomic replace. Append-only logs flush each record.
- A manifest hashes all accepted policy files and the active lesson snapshot.
- Unknown fields are rejected in protected execution schemas and preserved only where explicitly designed for extension.
- Absolute paths and `..` references are forbidden.
- Secrets never appear in policy, traces, exports, or proposals.
- Derived indexes may use SQLite or an in-memory cache only as disposable accelerators; flat files remain the source of truth.

### 7.3 Recovery

On startup:

1. load and validate the active registry and hashes;
2. load episode/plan/task state;
3. query current game/save identity and tick;
4. reconcile pending actions and observed effects;
5. invalidate stale observations and endpoint jobs;
6. rebuild resource locks and attention queue;
7. suspend tasks whose ownership or effects are uncertain;
8. resume only after fresh preconditions pass.

---

## 8. Core object model

### 8.1 Objective, plan, goal, and task

- **Objective:** human-owned outcome, priority, constraints, autonomy level, and acceptable risk.
- **Plan:** horizon, strategy, assumptions, alternatives, milestones, resource envelopes, revisions, and replan triggers.
- **Goal:** achieve or maintain an observed condition by a deadline. Maintenance goals remain active after recovery.
- **Task:** one bounded intent instantiated from a registered template, with dependencies, target scope, resource locks, matrix, timeout, retries, verification, and stop condition.

Task lifecycle:

```text
proposed → ready → running → awaiting_result → succeeded
                    │              │
                    ├→ blocked ────┤
                    ├→ suspended ──┤
                    ├→ failed
                    └→ cancelled
```

A task cannot report its own success. Only a verifier operating on a sufficiently fresh observation can transition it to `succeeded`.

### 8.2 Maintenance vector

The controller computes a colony-wide vector at every reconciliation:

```yaml
maintenance:
  immediate_safety: {state: pass|warning|fail|unknown, horizon_hours: 1}
  health:           {state: ..., horizon_hours: 6}
  food:             {state: ..., horizon_days: 3}
  shelter:          {state: ..., next_deadline: next_sleep_or_weather}
  temperature:      {state: ..., forecast_window_days: 3}
  mood:             {state: ..., per_pawn: true}
  power:            {state: ..., storage_and_generation_margin: ...}
  logistics:        {state: ..., hauling_and_storage_pressure: ...}
  defense:          {state: ..., readiness_vs_threat: ...}
```

Downstream research, wealth creation, expansion, caravans, and quests consume only declared surplus envelopes. A colony average may not hide one starving, freezing, infected, exhausted, or near-break pawn.

### 8.3 Resource reservations

Resources include:

- pawn-hours by capability and schedule window;
- exclusive pawn roles such as only doctor, cook, or warden;
- items and material quantities;
- power generation/storage margin;
- rooms, cells, work faces, paths, and map sites;
- research bench and current project ownership;
- Steward posture and stock-job ownership;
- game-write ownership for actions affecting shared policy.

Reservations have owners, quantities, start/end windows, priority, preemption rules, and release predicates. Emergency work may preempt ordinary reservations and records the displacement.

### 8.4 Workflows and actions

A workflow is a DAG of `observe`, `verify`, `task`, and `wait` nodes. Direct RPC nodes are forbidden. Task templates map selected options to registered `ActionTemplate` implementations.

Each action template defines:

- accepted typed parameters;
- required fresh predicates;
- maximum RPCs and wall time;
- dry-run requirements;
- desired-state/idempotency semantics;
- ownership of created bills, zones, designations, blueprints, policies, or queues;
- partial-failure handling;
- verification query and outcome window;
- rollback where physically possible.

---

## 9. Attention and event loop

### 9.1 Reconciliation cycle

At every wake:

1. ingest RimBridge events and Steward ledger changes;
2. refresh only observations needed by due obligations;
3. reconcile pending actions and verify due outcomes;
4. update maintenance goals and blockers;
5. apply deterministic emergency precedence;
6. form the eligible attention queue;
7. select one bounded turn;
8. persist state and choose the next event/deadline wake.

### 9.2 Queue contents

Include only:

- ready tasks;
- due verification checks;
- blocked tasks whose inspection is due or whose blocker changed;
- maintenance goals whose review is due;
- planner requests whose trigger is active;
- operator review obligations.

Awaiting work does not imply permission to issue it again.

### 9.3 Precedence and score

```text
operator pause/conflict
→ deterministic life-threatening emergency
→ critical deadline
→ overdue maximum-review obligation
→ scored ordinary work
```

Ordinary work starts with a visible score:

```text
0.35 urgency
+ 0.20 goal priority
+ 0.15 deadline proximity
+ 0.10 dependency unlock value
+ 0.10 time since review
+ 0.10 expected colony utility
− switching cost
− reserved-resource conflict
```

All terms are code-computed, recorded, and versioned. The exact weights are hypotheses and must be tested. Tie-break by earliest deadline, oldest attention, then stable task ID. Minimum focus dwell prevents oscillation but never blocks emergencies.

### 9.4 Game speed

- Pause for initial landing plan, operator takeover, uncertain write reconciliation, and emergencies requiring a consistent snapshot.
- Use normal speed when critical events are developing or model latency can miss an outcome.
- Use superfast during calm deterministic execution.
- Permit developer ultrafast only in explicitly labeled evaluation tracks after event latency is measured.
- Record requested speed, actual tick throughput, observation age, and model wait time.

Operator pause, game pause, and dispatcher ownership must be separate persisted states. Resuming one does not implicitly resume the others.

---

## 10. Decision matrices

### 10.1 Matrix contract

Each matrix is attached to a task template. Each matching row contains:

- typed predicates and explicit row priority;
- required feature names and freshness limits;
- no more than four productive choices;
- `CONTINUE` and `ESCALATE`;
- candidate-generation and binding rules;
- hard constraints and exclusions;
- selector question and criteria;
- deterministic fallback;
- action-template mapping;
- resource limits, cooldown, timeout, and verification;
- expected outcome windows and metrics.

Multiple same-priority matches are a validation error. The selector may return only an offered ID.

### 10.2 Example: routine planting decision

```yaml
id: matrix.food.planting
revision: 1
task_template: task.maintain_food_production
rows:
  - id: food.planting.short_horizon
    priority: 100
    when_all: [food_forecast_below_target, legal_growing_capacity_available]
    required_features:
      - days_until_shortage
      - growing_season_remaining
      - validated_plot_candidates
      - grower_capacity
      - current_crop_maturity
    productive_options:
      - {id: PLANT_RICE, action_template: maintain_rice_plot}
      - {id: PLANT_CORN, action_template: maintain_corn_plot}
      - {id: PLANT_POTATO, action_template: maintain_potato_plot}
      - {id: USE_INDOOR_FOOD, action_template: maintain_validated_indoor_food}
    fallback_options: [CONTINUE, ESCALATE]
    hard_constraints:
      - no_immature_crop_replacement_without_explicit_loss_budget
      - protected_food_and_medical_labor_preserved
      - plot_and_season_legality_verified
    verify: projected_and_actual_accessible_food_improved
```

Code computes growth windows, fertility, expected yield, labor, and plot legality. The selector judges the bounded tradeoff; it does not calculate crop math or invent a plot.

### 10.3 Routing policy

- One productive option: dispatch by rule.
- Two to four meaningful options: ask Tier 1.
- No productive option: `ESCALATE` or block with a capability gap.
- Missing critical fact: observe, do not ask the selector.
- Emergency: deterministic action or pause; never wait on a remote selector.
- Selector timeout/invalid result: matrix fallback.
- High-impact irreversible choice: require planner or human approval according to autonomy policy.

---

## 11. Holistic colony model

The original food → shelter → mood → research → combat order is useful for incremental implementation, but it is not a complete runtime ontology. The production agent must maintain the following interacting domains.

| Domain | Maintenance/outcome signals | Typical bounded workflows |
|---|---|---|
| Bootstrap and map selection | viable biome/season, nearby resources, skill coverage, faction access | choose tile, assess pawns, pause and stage landing plan |
| Labor and schedules | critical-role coverage, idle/overloaded pawns, sleep/recreation balance | set Steward posture, manage one exception, adjust schedule |
| Food and preservation | accessible food days, harvest forecast, spoilage, cooking capacity | forage/cook/plant/hunt policy, bills, freezer/paste system |
| Shelter and layout | beds, enclosure, temperature, safe access, completion forecast | reuse/open/excavate/hybrid site, phased build, verify use |
| Storage and logistics | exposed/deteriorating items, hauling backlog, travel cost, stockpile pressure | zones, filters, shelves, local input buffers, dumping areas |
| Power and temperature | generation/load/storage margin, outages, indoor exposure | add generation/storage, wire, fuel, set temperatures, shed load |
| Health and medicine | bleeding, infection/immunity margin, treatment delay, medicine reserve | rescue/tend reflex, medical policy, hospital, medicine stock |
| Mood and recreation | per-pawn break risk, thoughts, rest, recreation variety, comfort | cause-specific remedy, schedule, room/amenity, workload relief |
| Research and capabilities | prerequisite graph, bench uptime, useful unlock use | continue/select project, staff bench, implement unlocked capability |
| Production and equipment | bills, bottlenecks, apparel condition, weapons/armor readiness | threshold bills, crafting batch, clothing/equipment upgrades |
| Defense and incident recovery | threat paths, readiness, injuries, damage, recovery backlog | rally/posture, bounded tactical override, rescue, rebuild/rearm |
| Wealth and trade | wealth by utility, raid pressure, shortages, tradable surplus | buy bottleneck, sell low-utility excess, comms/caravan trade |
| Recruitment and prisoners | role gaps, prison safety, resistance, wardening capacity | rescue/capture, stabilize, recruit/release, assign safe room |
| Animals | food burden, pen capacity, useful products/hauling/combat value | tame/keep/slaughter thresholds, feed, pen, training |
| Quests, caravans, and world | reward/risk, travel time, home staffing, supplies | accept/decline, form caravan, trade/rescue objective, return |
| Endgame | selected victory path, prerequisites, threat preparation | ship/royalty/other plan, staged stockpile, defense and launch |

### 11.1 Cross-domain rules

- A mood symptom caused by hunger creates or links to a food task; it does not issue a competing mood action.
- Research starts only from maintenance surplus and must lead to an observed useful capability.
- Expansion is phased so a large blueprint does not scatter labor and delay immediate shelter.
- Wealth is a cost as well as an asset. Utility, defense, and bottleneck relief outrank raw market value.
- Trade buys hard bottlenecks or high-value capability; it does not consume survival reserves for replaceable luxuries.
- A caravan plan reserves enough home labor, defense, food, medicine, and travel margin before departure.
- Recruiting a pawn creates new food, bed, clothing, role, and threat-scaling consequences.
- Every incident includes a recovery plan: tending, undrafting, corpse handling, rebuilding, rearming, mood repair, and lesson capture.

---

## 12. Guide-derived strategy priors

The guide is a source of candidate rules, not ground truth. Distill approximately 30–60 timestamped rule cards into `brain/knowledge/rules/`. Each card records source, game/DLC/mod compatibility, context, exceptions, required features, recommendation, and evidence status.

Representative holistic priors include:

1. **Pause and stage the landing plan before unpausing.** Choose a site using soil, resources, travel, and defensibility; configure policies, roles, equipment, crops, stockpile, and the first shelter phase.
2. **Build in verified phases.** A large early blueprint scatters work and can leave no usable first-night shelter. Finish a minimal section, verify it, then expand.
3. **Use crop choice by horizon and context.** Rice is a fast bridge, corn reduces long-term labor after reserves exist, potatoes suit poor soil, and indoor production requires validated power and temperature.
4. **Maintain surplus without blind overproduction.** Account for new prisoners/recruits, season length, spoilage, freezer capacity, and labor.
5. **Minimize combat exposure.** Prefer controlled paths, cover, choke points, traps, range, kiting, and retreat over equal open fights; threat type changes the response.
6. **Connect research to current bottlenecks.** Reliable power, food preservation, weapons, armor, production, and fabrication matter only when follow-up labor and materials exist.
7. **Treat logistics as production.** Separate freezer from general storage, prioritize perishable storage, place inputs near benches, maintain hauling capacity, and limit unnecessary travel.
8. **Manage the home area intentionally.** It determines cleaning, repair, and firefighting scope; oversized areas waste labor and create risk.
9. **Upgrade construction materials with context.** Fast temporary wood can satisfy an urgent deadline; durable nonflammable construction becomes valuable later. Do not demolish working shelter before a replacement is usable.
10. **Protect critical pawn roles.** The best miner who is also the only cook or doctor is not fully available mining capacity.
11. **Use individual mood causes.** Tables, light, recreation variety, comfort, clean rooms, sleep, clothing, food quality, relationships, pain, and workload need different remedies.
12. **Control wealth growth.** Sell or dispose of low-utility excess, invest in survivability and capability, and avoid producing wealth that increases threat faster than readiness.
13. **Trade for bottlenecks.** Components, medicine, critical equipment, and unavailable resources can be worth unfavorable prices; use the best safe negotiator.
14. **Keep a doctor prepared.** Treatment latency, self-tend policy, medicine access, and hospital readiness matter before the emergency.
15. **Always include recovery.** A raid is not over when hostiles leave; injuries, fire, breaches, forbidden drops, corpses, damaged mood, and lost production require follow-up.

Each prior starts as `source_prior`. It becomes `supported` only through context-matched real evidence and review.

---

## 13. Spatial planning and construction

### 13.1 Candidate generation

A deterministic spatial planner shall generate and validate:

- reuse of existing rooms or ruins;
- open-ground construction;
- excavation;
- temporary-plus-durable hybrid plans;
- expansions, corridors, work rooms, storage, freezer/kitchen flow, hospitals, prisons, power, and defensive layers.

Candidates may be rotated, resized, irregular, and phased. Each binds an immutable candidate ID to cells, access, work faces, expected materials, pawn-hour range, critical path, roof/support checks, temperature needs, fire risk, threat routes, and opportunity cost.

### 13.2 Phased execution

```text
survey → reserve → clear/mine → inspect revealed state
→ construct shell/utilities → furnish/configure → verify use
```

Do not place unreachable later blueprints behind unmined rock. Re-estimate after every phase, worker loss, reservation change, revealed hazard, or deadline miss. `ui.build` success means placement, not completed shelter; observed enclosure, access, temperature, and use determine success.

### 13.3 Layout utility

Evaluate layout by colony utility rather than market wealth:

- walking and hauling time;
- adjacency of fields, raw storage, kitchen, meals, dining, workshop inputs, hospital, and defense;
- clean/dirty workflow separation;
- expansion room and critical-path obstruction;
- fire breaks and material definitions;
- escape, rescue, breach, infestation, and roof-collapse risk;
- power wiring and generation constraints;
- shelter completion before near deadlines.

---

## 14. Execution through Steward and RimBridge

### 14.1 Preferred altitude

Use the highest sufficient control level:

```text
standing order / stock target / posture
→ persistent game policy or threshold bill
→ bounded order or gizmo
→ validated designation/blueprint/zone
→ direct pawn job
→ reflective engine write (normally prohibited)
```

### 14.2 Steward ownership

- Steward owns routine work priorities and stock jobs.
- Standing orders own configured combat, rescue, unforbid, corpse, bed, policy, blueprint, and fire reflexes.
- The framework owns strategic targets, posture, resource reservations, sites, research backlog, workflows, and verification.
- Manual overrides must explicitly suspend or reconcile the affected owner, then return ownership when the condition clears.
- One arbiter composes a single Steward posture so domain tasks do not overwrite one another.
- Keep only the next validated research project in Steward’s queue. The framework retains the backlog.

### 14.3 Idempotency

Dispatch desired states, not repeated commands:

- “stock target for wood = 600 under policy revision 12,” not “raise wood again”;
- “bill exists with target 15,” not “add another bill”;
- “site phase 2 has these owned designations,” not “mine around here”;
- “research project X is current and owned by framework,” not “set X every turn.”

Before retrying an uncertain action, query whether the intended effect already exists.

---

## 15. Self-improvement and knowledge lifecycle

### 15.1 Separate the three loops

1. **Execution recovery:** refresh, reconcile, safely retry, select another offered method, or block.
2. **Current-plan repair:** revise tasks, dependencies, reservations, or goals for the current colony.
3. **Reusable policy learning:** propose and test changes for future decisions.

Success at recovery or repair does not prove a reusable lesson.

### 15.2 Immutable evidence

Every decision record includes:

- episode/start-save and environment manifest;
- plan, goal, task, attempt, attention, matrix, policy, lesson, adapter, and endpoint revisions;
- exact observation features and freshness;
- scheduler score and competing obligations;
- all generated candidates, exclusions, and reasons;
- selected, fallback, and actually executed actions;
- RPC results and uncertain/partial effects;
- latency, usage, cost, and game ticks elapsed;
- expected result, observation windows, actual result, and intervening incidents.

Do not infer outcomes for unchosen candidates.

### 15.3 Failure classification

Classify failures before proposing a fix:

- planning or assumption;
- decomposition/dependency;
- attention/deadline;
- observation/freshness;
- feature or candidate generation;
- matrix criteria or selector judgment;
- provider/adapter transport;
- resource arbitration;
- dispatch/ownership/idempotency;
- verification/attribution;
- external incident;
- unknown/insufficient evidence.

### 15.4 Lesson ledger

A lesson revision stores:

- stable ID, status, statement, provenance, and source traces;
- applicability, exceptions, game/mod/policy compatibility;
- map, pawn-capacity, season, threat, deadline, and resource context;
- expected versus observed outcomes;
- supporting and contradicting evidence;
- independent start-save coverage;
- competing explanations and confidence basis;
- proposed effect on policy or ranking;
- human review and promotion lineage.

Statuses: `prior`, `hypothesis`, `supported`, `contradicted`, `superseded`.

Retrieval occurs before strategic planning, matrix ranking, retries, and failure review. Context mismatches are excluded with reasons. Hard facts, legality, reservations, and current safety always override a lesson.

### 15.5 Policy proposal and promotion

The strong reviewer may propose changes to:

- planning guidance and replan triggers;
- task/workflow decomposition;
- attention weights, deadlines, and cooldowns;
- matrix rows, criteria, examples, thresholds, and parameters;
- knowledge rule scope or lesson status.

It may not directly activate them. Promotion pipeline:

```text
failure cluster or outcome review
→ typed diagnosis with trace references
→ one scoped proposal in proposal workspace
→ schema/reference/static validation
→ saved decision fixtures
→ matched development-save trials
→ held-out guardrail check
→ human approval (default)
→ atomic policy snapshot activation between turns/episodes
→ monitored cohort
→ retain or rollback with lineage
```

New executable tools, RPCs, predicates, watchers, or mod changes require code review and normal tests. The upstream watchdog should remain a separate, human-deployed code-correction mechanism; it is not gameplay policy learning.

### 15.6 Low-risk automatic adaptation

Only after controlled evaluation may the system automatically promote bounded numeric parameters, such as a routine stock target or review interval. Automatic promotion requires:

- no emergency/combat/medical scope;
- a declared safe interval;
- enough independent contexts;
- zero guardrail regressions;
- a rollback snapshot;
- a limited exploration budget, initially no more than 5% of eligible low-risk training choices.

---

## 16. Evaluation

### 16.1 Environment control

Record and freeze:

- RimWorld/game build, DLCs, mods, and load order;
- scenario, storyteller, difficulty, map/tile settings;
- full starting save hash, not just world seed;
- policy, lesson, adapter, endpoint/model, and code revisions;
- speed/pause policy, Steward configuration, action budgets, and observation access;
- assisted actions and manual interventions.

### 16.2 Experimental arms

- **A:** frozen upstream free-form RimAgent controller.
- **B:** new framework with deterministic matrix fallback only.
- **C:** same framework with fixed cheap/local selector.
- **D:** same as C with a frozen improved policy.
- **E:** optional trained local outcome selector without remote semantic features.

Hold every other component fixed when comparing selectors or planners.

### 16.3 Metrics

Priority order:

1. **Integrity:** survival, original colonist deaths, total deaths, illegal writes, unhandled emergency stalls, forced reloads, manual interventions.
2. **Maintenance:** hunger pawn-hours, unsafe temperature, unprotected sleep, untreated/bleeding time, individual distress, mental breaks, outages, spoilage.
3. **Useful progress:** verified capabilities in use, defensible infrastructure, incident recovery, selected endgame milestones.
4. **Efficiency:** model cost/game-day, planner and selector calls, latency, actual TPS, game days/wall hour, writes, duplicate rate, fallback rate.
5. **Framework quality:** verified goal success, deadline misses, overdue attention, blocked duration, plan churn, repeated failures, trace completeness, diagnosis time.

Report wealth but do not maximize it.

### 16.4 Test ladder

1. Schema, graph, matrix, reservation, recovery, and adapter unit tests.
2. Recorded observation and decision fixtures, including stale/missing data and malformed provider output.
3. Shadow mode with no game-write authority.
4. Short matched bootstrap/food/shelter trials.
5. Combined maintenance trials including power, health, mood, and logistics.
6. Research/production/trade/recruitment trials.
7. Matched combat incidents and recovery.
8. Caravans, quests, season transitions, and selected endgame path.
9. Sixty-day holistic pilots.
10. Locked held-out final evaluation.

Group uncertainty by starting-save family, not by thousands of correlated decisions from one colony.

---

## 17. Required code changes in the RimAgent fork

### 17.1 New packages

```text
agent/rimagent/framework/
  models.py             # plan/goal/task/workflow and lifecycle schemas
  store.py              # atomic flat-file state and append-only logs
  registry.py           # policy registry/load order/references/snapshots
  reconcile.py          # event ingestion and restart reconciliation
  attention.py          # due obligations, precedence, scoring
  resources.py          # reservations and preemption
  maintenance.py        # holistic maintenance vector
  lineage.py            # IDs/revisions/trace links

agent/rimagent/providers/
  contracts.py
  registry.py
  openai_chat.py
  typesafe_systemone.py
  local_structured_http.py
  stubs.py
  capability_tests.py

agent/rimagent/policy/
  predicates.py
  features.py
  candidates.py
  matrices.py
  routing.py
  dispatcher.py
  verification.py
  failure.py
  lessons.py
  promotion.py

agent/rimagent/domains/
  bootstrap.py
  labor.py
  food.py
  shelter.py
  logistics.py
  power_temperature.py
  health.py
  mood.py
  research.py
  production.py
  defense.py
  wealth_trade.py
  recruitment.py
  animals.py
  world.py
  endgame.py
```

Domains register predicates, features, candidate generators, action templates, and verifiers. They do not own provider clients or write directly to RimBridge.

### 17.2 Existing files to adapt

- **`config.py`:** load endpoint roles, framework mode, autonomy policy, budgets, and active policy registry while retaining legacy config compatibility.
- **`llm.py`:** move OpenAI/Qwen-specific behavior behind `providers/openai_chat.py`; preserve capture via canonical request metadata.
- **`runner.py`:** add `framework` mode beside legacy single/parallel modes; replace `play_step` with reconcile → attention → route → dispatch → verify; preserve polling, speed, episode, dashboard, and autosave infrastructure.
- **`loop.py`:** retain the legacy free-form loop and reusable situation rendering; expose observation gathering as independent functions so framework packets do not invoke a tool conversation.
- **`reflect.py`:** stop live brain mutation in framework/scored mode; emit typed plan repairs, lesson candidates, and policy proposals.
- **`registry.py`:** keep tool registration for legacy/operator recovery; framework dispatch uses an explicit action-template allowlist rather than exposing all tools to a model.
- **`roles.py`:** disable parallel writes in framework mode. Optional specialists become read-only candidate advisers whose output still enters the single dispatcher.
- **`memory.py`:** retain notebook/journal for operator readability, but make structured plan/task/lesson files authoritative.
- **`watchers.py`:** classify watchers as read-only alerts or validated deterministic actions with ownership metadata; prefer Steward standing orders for high-frequency reflexes.
- **dashboard:** add plan tree, task board, attention queue, maintenance vector, matrix inspector, trace viewer, endpoint health/cost, proposal diff, lesson evidence, experiment comparison, and explicit pause/write ownership.

### 17.3 Configuration mode

```yaml
controller:
  mode: framework       # legacy_single | legacy_parallel | framework
  autonomy: supervised  # shadow | supervised | autonomous
  policy_registry: brain/policy/registry.yaml
  active_lesson_snapshot: lesson-snapshot-0001

endpoints:
  planner:
    adapter: openai_chat_completions
    base_url: ${PLANNER_BASE_URL}
    model: ${PLANNER_MODEL}
    secret_ref: secret:RIMWORLD_PLANNER_API_KEY
  decision_selector:
    adapter: local_structured_http   # or typesafe_systemone
    base_url: http://127.0.0.1:9000/v1/select
    model: local-laya-deployment
    auth: none
    fallback: rules
```

Environment substitution resolves non-secret deployment settings; a backend secret resolver handles credentials.

---

## 18. Implementation roadmap

### Phase 0 — fork, pin, and characterize

- Create a user-owned RimAgent fork pinned to a known upstream commit.
- Run current Python and Steward tests.
- Capture representative observations and existing controller episodes.
- Establish Windows launch/build paths and live RimWorld connectivity.

**Exit:** reproducible legacy baseline and environment manifest.

### Phase 1 — durable core and shadow scheduler

- Implement schemas, registry, flat-file store, recovery, lineage, goals/tasks/workflows, reservations, maintenance vector, and attention queue.
- Load migrated versions of the existing BVRimAgent settings.
- Run the framework in shadow mode beside legacy play.

**Exit:** restart-safe trace from objective to selected task; no game writes.

### Phase 2 — provider boundary and cheap selector

- Add adapters and capability tests.
- Implement matrix validation, candidate binding, deterministic routing, stale-result rejection, and endpoint budgets.
- Test Jev and/or local Laya only after stub fixtures pass.

**Exit:** endpoints can be swapped independently; selector can never return or execute an unoffered action.

### Phase 3 — holistic bootstrap vertical slice

Implement one integrated landing plan rather than food alone:

- bootstrap/map assessment;
- initial labor/posture and equipment;
- immediate food and planting;
- minimal shelter;
- stockpile/logistics;
- basic health policy;
- initial power/research intent;
- minimal defensive readiness.

Use phased construction and verify every outcome.

**Exit:** a matched start can reach stable first-week maintenance with fewer strong-model calls than legacy RimAgent.

### Phase 4 — stable colony maintenance

Add:

- seasonal food forecasts and preservation;
- power/temperature margins;
- health and medicine;
- individual mood causes;
- storage/workshop logistics;
- production, clothing, and equipment maintenance;
- research capability graph and useful-unlock verification.

**Exit:** 20–30 day matched trials maintain all enabled domains without hidden starvation of prior goals.

### Phase 5 — wealth, people, and world interaction

Add:

- wealth utility and threat-cost accounting;
- trade candidate generation;
- prisoners/recruitment and role-gap planning;
- animal value and burden;
- quests and caravans with home-capacity reservations.

**Exit:** the agent can explain and safely execute accept/decline, buy/sell, recruit/release, and caravan decisions.

### Phase 6 — defense, recovery, and endgame

- Keep deterministic immediate combat enabled from the start.
- Add cheap-selector posture recommendations first in shadow mode.
- Add threat-specific bounded tactical overrides only after matched incident tests.
- Add full post-incident recovery.
- Add one operator-selected victory path and its long-term milestone graph.

**Exit:** matched incident and long-horizon trials meet survival guardrails and preserve complete action/outcome lineage.

### Phase 7 — evidence-backed self-improvement

- Add failure clustering, lesson retrieval, strong reviewer proposals, fixtures, matched trial runner, promotion UI, atomic activation, monitoring, and rollback.
- Disable active mid-episode policy edits in scored mode.

**Exit:** one real repeated failure produces a scoped proposal that passes or fails declared gates; a bad proposal is rejected; rollback preserves evidence.

---

## 19. Acceptance criteria

The project is ready for autonomous holistic trials only when all of the following hold:

### Control and safety

- One dispatcher owns every framework game write.
- Emergency behavior never waits for a model endpoint.
- Stale, malformed, unoffered, or mismatched model results cannot execute.
- Restart recovery reconciles uncertain actions before retry.
- Operator pause and takeover block writes and preserve ownership state.

### Efficiency

- Routine pawn work runs in Steward without model calls.
- At least 80% of framework attention turns route deterministically or to the cheap selector during stable play.
- Strong-model calls are attributable to declared strategic triggers.
- Cost, latency, and game-time impact are visible per role and episode.

The 80% threshold is an initial target to validate, not a reason to suppress necessary escalation.

### Planning and holistic play

- The active plan spans immediate, tactical, seasonal, strategic, and endgame horizons.
- Maintenance gates cover safety, health, food, shelter, temperature, mood, power, logistics, and defense.
- Research, expansion, wealth, caravans, and quests consume only explicit surplus budgets.
- Cross-domain conflicts resolve through shared reservations rather than independent overwrites.
- Incidents produce verified recovery work.

### Reviewability

From the dashboard or exported report, a reviewer can answer:

- What are we trying to achieve now and later?
- Why does this task have attention?
- Which facts are fresh, stale, or unknown?
- Which options were legal, excluded, and selected?
- What did code actually dispatch?
- Did the intended outcome occur?
- Which lesson affected the choice?
- What evidence supports a proposed policy change?

### Learning

- Lessons preserve applicability, contrary evidence, and provenance.
- Active policy and lesson snapshots are frozen for scored runs.
- Held-out outcomes cannot enter planning or learning until retired.
- No policy proposal activates itself by default.
- Promotion and rollback preserve full lineage.

---

## 20. Initial engineering test matrix

At minimum, implement fixtures for:

- already-satisfied maintenance goal;
- missing/stale observation;
- cyclic workflow or plan dependency;
- conflicting pawn/material/site reservations;
- only cook is also best miner/researcher/doctor;
- action acknowledged but effect absent;
- action timed out but effect already exists;
- duplicate bill, blueprint, designation, or stock target;
- emergency interrupt during a build or model request;
- human changes game policy while framework owns it;
- selector returns an unoffered option, malformed JSON, no confidence, timeout, or late response;
- planner references unknown predicate/action/template;
- provider swap with pending responses;
- low food with inaccessible food candidates;
- crop plan invalidated by season or cold snap;
- shelter blueprint placed but room not enclosed;
- miner lost during excavation;
- power loss affecting food or temperature;
- one pawn’s mood crisis hidden by colony average;
- research complete but capability never implemented;
- wealth growth without defensive readiness;
- caravan that would remove critical home coverage;
- raid followed by untreated injury, breach, fire, or mood recovery;
- lesson context mismatch and preserved counterevidence;
- synthetic example or held-out result attempting promotion;
- crash/restart with pending action and resource locks.

---

## 21. First implementation decision

Build the framework first around a **holistic first-week plan**, while retaining food recovery as the smallest decision-matrix test. This is preferable to shipping a food-only controller that cannot coordinate shelter, labor, medicine, storage, power, and defense during landing.

The first live scenario should demonstrate:

1. strong planner creates a bounded first-week plan from a fresh landing snapshot;
2. deterministic code instantiates goals, workflows, reservations, and deadlines;
3. Steward performs routine pawn work;
4. cheap/local selector chooses among validated crop, shelter, storage, and build-phase options;
5. deterministic emergency handling interrupts safely;
6. tasks complete only after observed outcomes;
7. one failure becomes an evidence-linked proposal without changing active policy;
8. the same start is replayed with deterministic selection for comparison.

That vertical slice proves the intended architecture: expensive intelligence sets and improves strategy; cheap intelligence chooses among good local options; deterministic automation performs and verifies most gameplay.
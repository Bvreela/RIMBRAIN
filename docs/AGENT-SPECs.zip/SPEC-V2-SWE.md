# RimWorld Agent Framework — Implementation Spec (v2)

**Status:** Working implementation spec. Revises `LOCAL-FIRST-HOLISTIC-AGENT-SPEC.md`; that document remains the rationale/background reference.
**Target:** A user-owned fork of `zorrobyte/rimagent`, preserving RimBridge and Steward.
**Objective:** Play complete RimWorld colonies through an API. Deterministic automation does the playing; a cheap/local model picks among validated options; a strong model plans and reviews, sparsely. All durable state lives in human-readable flat files.

This revision exists because v1 reads like a finished system description. It is actually a multi-phase research project. This spec is organized around **what can fail, what we build first, and how we know when to stop**.

---

## 1. The bet

We are making three falsifiable claims. The evaluation plan exists to test them, not to confirm them.

- **B1 — Routine play doesn't need a strong model.** Deterministic rules plus a bounded-choice cheap selector can match a strong-model-per-wake baseline on survival and maintenance outcomes, at a fraction of the cost. *Falsified if:* Arm C (cheap selector) fails to beat Arm B (rules-only) on matched dev trials — in which case we ship Arm B and the selector machinery stays optional. Also falsified if Arm B doesn't beat Arm A (legacy free-form loop), which would mean the whole framework isn't earning its complexity.
- **B2 — Sparse strong-model planning pays for itself.** A planner called on declared triggers improves long-horizon outcomes (deadline misses, milestone progress, plan churn) vs. heuristic planning. *Falsified if:* removing the planner doesn't measurably hurt dev-trial outcomes — then it becomes an advisory/reporting tool.
- **B3 — Evidence-backed policy iteration converges.** Reviewed proposals + matched trials + promotion produce net improvement over frozen policy. *Falsified if:* after Phase 7 infrastructure exists, proposals fail gates at a rate suggesting the signal is noise.

If all three fail, the honest deliverable is "better Steward standing orders + flat-file memory," and we should say so.

---

## 2. Risk register

Ranked by likelihood × damage. Every phase's exit criteria should be checked against these.

| # | Risk | Why it's real | Early signal | Mitigation |
|---|---|---|---|---|
| 1 | **Scope never converges** | 16 domains × ~30 modules × eval harness is far beyond a single milestone | Phase exits slip; nothing is playable end-to-end | Spine-first sequencing (§12). The deferred list (§15) is contractual, not aspirational. |
| 2 | **Maintenance metrics are wrong** | "Days of accessible food" requires pathing, forbidden-item rules, spoilage, prisoner count. Computed wrong, every decision inherits the error | Phantom starvation alerts, or missed real starvation | Every metric is shadow-validated against a human-labeled save before it may gate attention. Metrics ship with a known-failure-modes note. |
| 3 | **Selector adds nothing** | If code already computes candidates and expected costs, argmax may beat a small model | Arm B ≈ Arm C on labeled decision fixtures | `rules` is the default selector forever (§6). A model selector must win on fixtures before it gets live authority. |
| 4 | **Attribution is noise** | Storyteller RNG, traders, weather confound "did our action cause the outcome" | Verifier flapping; lessons accumulating garbage | Verify *state deltas*, never claim credit. Policy learning happens only at the matched-trial aggregate level (§9.4). |
| 5 | **Scheduler/reservation complexity** | Locks + preemption + priorities = deadlock, starvation, priority inversion | Tasks stuck `awaiting_lock`; circular waits | v1 has exclusive lock categories and emergency preemption only. No quantities, windows, or inheritance until a measured conflict demands them (§9.3). |
| 6 | **Eval wall-clock** | No headless RimWorld. One game day ≈ real minutes at 3×; a 60-day pilot is real *days* per run per arm | Test ladder never actually executed | Explicit eval-hours budget (§11.4). Short matched trials + fixtures carry most coverage; long pilots are rare and scheduled. |
| 7 | **Flat-file corruption on crash** | Windows file locking, mid-append crash, no fsync | Torn JSONL tail; lost reservation state | Per-record flush+fsync before ack; torn-tail truncation tolerated on load; state files via tmp+rename+dir-fsync (§8). |
| 8 | **Game runs while agent is down** | Reservations and pending actions go stale; restart double-writes | Post-restart duplicated bills/designations | Agent requests game pause on clean shutdown; restart enters reconcile-only mode until uncertain writes resolve (§9.5). |
| 9 | **Schema churn corrupts state** | Early phases will change schemas weekly | Old runs unloadable; silent misreads | `schema_version` per file kind + explicit migrations from day one; loader refuses unknown *newer* versions rather than guessing. |
| 10 | **Legacy loop stays the real path** | Framework mode becomes dead code nobody dogfoods | All real runs still `legacy_single` | Framework becomes the default controller mode at Phase 3 exit; legacy is opt-in recovery mode thereafter. |
| 11 | **Emergency path depends on model latency** | A reflex routed through a model call kills pawns | Bleeding pawn waits on HTTP timeout | Emergencies are deterministic-only, enforced structurally: the emergency code path has no access to a provider client (§4). |

---

## 3. Non-negotiable invariants

These are the load-bearing walls. Everything else is negotiable.

1. **One writer.** All game-state changes go through a single dispatcher queue. No component with a provider client may hold a game-write handle. This is enforced by code structure, not convention.
2. **Typed intent only.** Models return option IDs and structured proposals. No free-form text is executed; no model may emit RPC names, coordinates, object IDs, or quantities it wasn't offered.
3. **Emergencies never wait on a model.** Deterministic reflexes and Steward standing orders own life-threatening response.
4. **Tasks cannot grade themselves.** Only a verifier operating on a sufficiently fresh observation may mark a task `succeeded`.
5. **Flat files are authoritative.** Memory is a rebuildable cache. Restart loses nothing committed.
6. **Policy is frozen during scored runs.** No live brain edits mid-episode. Proposals activate only through the promotion pipeline, between episodes, atomically.
7. **Nothing promotes itself.** Proposals require human approval by default. Automatic promotion of bounded numeric params is a Phase 7+ privilege with guardrails, not a starting feature.

---

## 4. Architecture

```text
RimWorld + RimBridge
        │ events, state, RPC results
        ▼
Observation reconciler ──► derived features ──► flat-file trace log
        ▼
Goal/task store ◄──── Strategic planner (strong, sparse, triggered)
        ▼
Attention scheduler + lock arbiter          [single asyncio loop]
        │ one focused task
        ▼
Candidate generator + validator (deterministic)
        │ ≤4 productive options + CONTINUE + ESCALATE
        ▼
Router ─┬─ deterministic rule (default path)
        ├─ cheap selector (Jev/local adapter, optional)
        └─ planner escalation (declared triggers only)
        │ typed option ID
        ▼
Dispatcher ──► Steward posture / allowlisted bounded workflow
        │        (THE ONLY GAME WRITER)
        ▼
Verifier ──► update state, release locks, append evidence,
             emit failure packet

Offline: evidence ──► reviewer ──► staged proposal ──► fixtures
      ──► matched trials ──► human gate ──► atomic activation
```

### 4.1 Runtime model (new — v1 was silent on this)

- One Python process, **one asyncio event loop**. Reconciler, scheduler, router, dispatcher, verifier, and provider adapters are coroutines/tasks on that loop.
- **The dispatcher is a single task consuming a FIFO queue.** It is structurally impossible for two writes to interleave, and impossible for any coroutine holding a provider client to enqueue writes directly — writes are enqueued as *validated intents* and re-checked at dispatch time.
- Provider calls are cancellable futures with per-adapter timeouts. Timeout/cancel → router applies the matrix fallback. No blind retry: retries must re-verify preconditions because game state moved.
- In-flight provider responses whose request revision is stale (matrix/policy/observation moved on) are **discarded**, logged, and counted as `stale_response` metrics.

### 4.2 Authority boundaries

| Component | Reads game | Chooses policy | Writes game | Changes active policy |
|---|---:|---:|---:|---:|
| RimBridge | Yes | No | Executes validated RPC | No |
| Steward / standing orders | Yes | Fixed deterministic policy | Yes (its own scope) | No |
| Observation/features | Yes | No | No | No |
| Attention scheduler | Derived state | Picks task by published rules | No | No |
| Cheap selector | Relevant packet only | One offered option | No | No |
| Strategic planner | Planning packet | Proposes plans/tasks | No | No |
| Dispatcher | Fresh state at dispatch | No | Yes, allowlisted only | No |
| Reviewer | Saved evidence | Proposes policy diff | No | No |
| Promoter | Recorded runs | Applies declared gates | No | Atomic activation only |
| Human operator | Full review surfaces | Yes | Via controlled override | Yes |

### 4.3 Dispatch requirements

Every write requires: `action_intent_id` + idempotency key; active plan/task/matrix/policy/observation/endpoint revisions; current ownership of required locks; fresh preconditions and a still-legal bound target; an allowlisted action template; bounded write count + stop condition; a verification schedule. Results created against stale revisions are discarded.

---

## 5. Model roles and routing

Two provider-neutral roles: **`planner`** (`PLAN`, `REPAIR`, `REVIEW_POLICY`) and **`decision_selector`** (`SELECT` over a closed set). Same endpoint may fill both; each role has independent limits, prompts, capability tests, and revisioned config. Game logic never branches on a provider name.

### 5.1 Tier 0 — no model

Deterministic routing when: one productive option; pure observation/verify; desired state already holds; standing order owns the reflex; emergency invariant; not-yet-due awaiting task; configured safe fallback after timeout; arithmetic decides. **This is the default path, not the degenerate path.**

### 5.2 Tier 1 — the selector question (rewritten)

v1 assumed the selector's value. It is unproven. Honest framing: after code computes candidates, legality, cost, risk, and expected effect, the selector's marginal contribution is *judgment over tradeoffs we can't easily score* — flexibility preservation, compound second-order effects, "this is technically legal but dumb." Whether a small local model does that better than a declared scoring function is an empirical question.

Therefore:

- `rules` (deterministic argmax over declared per-option scores) is **the shipping default**, permanently.
- A model selector is added behind an adapter and must **beat `rules` on labeled decision fixtures** before it may run live, and beat it again on matched dev trials before it may run unsupervised.
- The matrix/bounded-option machinery is retained either way — it's the safety envelope and the fixture format, not a favor to the model.
- The selector returns exactly one offered option ID or typed abstention. Never anything else.

### 5.3 Tier 2 — planner triggers

Planner is called only on: episode init/save adoption; human objective change; invalidated plan assumption; colonist gained/lost/incapacitated; biome/season/tech/threat-profile transition; goal infeasibility or cross-domain conflict; failure cluster over threshold; novel incident with no applicable matrix; milestone completion; scheduled review (start at 1/game-day, adaptive later); end-of-episode review. Blocked actions, stale observations, and transient RPC errors are handled locally first.

### 5.4 Budgets

Track per role: calls/day and /episode; tokens in/out when reported; cost; p50/p95 latency; game ticks elapsed while waiting; fallback/escalation frequency; stale-response rate; valid-selection/useful-plan rates.

```yaml
budgets:
  planner:    {max_calls_per_game_day: 2, max_calls_per_episode: 40, max_repair_attempts_per_operation: 1}
  selector:   {max_calls_per_attention_turn: 1, max_calls_per_game_hour: 4}
  deterministic_first: true
  on_budget_exhausted: {selector: rules_fallback, planner: continue_valid_plan_or_pause_if_required}
```

These are guardrails to tune, not claims of optimality.

---

## 6. Provider contracts

`PlanRequest` carries operation + request ID, objective/constraints, phase/horizon, maintenance vector + incidents, relevant observations *with freshness stamps*, current plan/goal/task revisions, capability/predicate/workflow/task-template catalogs, applicable lesson summaries *with counterevidence*, resource envelopes, allowed change scope, output budget.

`PlanProposal` carries assumptions + missing facts, strategy + alternatives, goals with measurable predicates, task/workflow refs with acyclic deps, deadlines/envelopes/replan triggers, concise rationale claims, explicit inability/observation requests. Local validation rejects unknown IDs, cycles, unsupported actions, missing verification, conflicting locks, unbounded work, protected-policy edits.

`DecisionRequest` carries all revisions, one task intent, named facts/buckets, pre-evaluated hard constraints, exact offered option IDs + descriptions, per-option predicted cost/risk/time/effect, deadline, schema. `DecisionResult` is `{request_id, option_id, status, confidence?, probabilities?, rationale?, provider_metadata}`. Confidence is nullable and provider-specific; no universal threshold — gating uses per-endpoint calibration only.

Adapters: `openai_chat_completions`, `typesafe_systemone` (Jev), `local_structured_http` (Laya-class local endpoint — real contract TBD, capability tests gate adoption), `stub_planner`, `stub_selector`. An adapter owns transport, auth, serialization, retries, cancellation, parsing, identity. It may not alter matrix semantics or candidate IDs.

Capability tests (no game writes): schema-valid output, offered-option enforcement, explicit abstention, malformed/truncated handling, timeout + rate-limit behavior, absent-confidence handling, correlation + stale-result rejection, independent endpoint swap with in-flight requests (in-flight → cancel or drain, never execute).

---

## 7. Persistence

Flat files are authoritative; in-memory state is a rebuildable cache.

### 7.1 Layout

Unchanged from v1 §7.1 — `brain/policy/{registry,accepted,proposals,snapshots}`, `brain/plans/{active,archive}`, `brain/knowledge/{rules,lessons,skills}`, `brain/state/{episode,goals,tasks,reservations,pending-actions,workflow-cursors}`, `brain/memory/`, `runs/<episode-id>/{manifest,observations,attention,decisions,actions,outcomes,failures,metrics,endpoint-traffic,final-report}`, `runs/evaluations/`.

### 7.2 File rules (with Windows specifics added)

- YAML for human-edited policy/plans/matrices/snapshots. JSONL for append-only evidence/decisions/outcomes/lessons. Stable IDs over labels/file-order.
- Every record: `schema_version`, object revision, created time, episode, provenance.
- **Durability:** JSONL appends are flushed + `os.fsync`'d before the record is acknowledged upstream. State files are written to a sibling temp file, fsync'd, `os.replace`'d, then the containing directory is fsync'd. On load, a torn final JSONL line is truncated with a `recovery.torn_tail` log entry, not a fatal error.
- A manifest hashes all accepted policy files + the active lesson snapshot.
- **Schema versioning:** each file kind has an integer version and a `migrate_vN_to_vN+1` function. The loader refuses files with a *newer* version than it understands. During a scored run series, schemas are frozen — migrate between series, never mid-series.
- Unknown fields rejected in execution schemas; preserved only where designed for extension.
- No absolute paths, no `..`, no secrets in any file.
- SQLite/in-memory indexes allowed as disposable accelerators; rebuild from files.

### 7.3 Log volume

Estimate before building retention: a wake emits ~5–20 records across the run logs. At ~4 wakes/game-hour and ~20 min/game-hour at 3×, that's roughly 5–15 MB per game-day of JSONL — trivial for disk but large for context windows and diff review. Run logs compress at episode end; `runs/` older than N days archive to a cold dir. Measure in Phase 1 and adjust.

### 7.4 Recovery

On startup: validate registry + hashes → load episode/plan/task state → query game/save identity + tick → reconcile pending actions against observed effects → invalidate stale observations/endpoint jobs → rebuild locks + attention queue → **suspend tasks with uncertain ownership/effects** → resume only after fresh preconditions pass. Restart is reconcile-only mode: no new work until pending writes resolve or are safely abandoned with logged reason.

---

## 8. Core object model

### 8.1 Objective → plan → goal → task

- **Objective:** human-owned outcome, priority, constraints, autonomy, acceptable risk.
- **Plan:** horizon, strategy, assumptions, alternatives, milestones, resource envelopes, revisions, replan triggers.
- **Goal:** achieve *or maintain* an observed condition by a deadline. Maintenance goals persist across recovery.
- **Task:** bounded intent from a registered template: deps, target scope, locks, matrix, timeout, retries, verification, stop condition.

Lifecycle: `proposed → ready → running → awaiting_result → succeeded`, with `blocked`, `suspended`, `failed`, `cancelled`. Verifier-only success (invariant 4).

### 8.2 Maintenance vector

Per v1 §8.2 — colony-wide vector recomputed each reconciliation across safety, health, food, shelter, temperature, mood (per-pawn, never hidden by averages), power, logistics, defense. Downstream work consumes only declared surplus envelopes.

**Added caveat (risk #2):** every maintenance signal is a *computed estimate* with known failure modes. Each ships with: the predicate definition, its freshness requirement, a shadow-validation fixture against a labeled save, and an `unknown` state that the scheduler treats as "observe first," never as "fine."

### 8.3 Locks (scoped down from v1's reservation system)

v1 specified quantities, windows, priorities, preemption rules — an OS scheduler. v1 locks are simpler:

- **Exclusive categories only:** a site, a pawn's special role (only-doctor, only-cook), a policy object (a bill, a stock target, a zone), the dispatcher itself.
- Lock = `{category, object_id, owner_task_id, acquired_at, expires_at}`.
- **No partial quantities, no preemption except emergencies**, which force-revoke and record the displacement for the recovery planner.
- Deadlock is impossible by construction: a task holds at most the locks for one bounded action, all acquired atomically (all-or-nothing), with expiry.
- If dev trials show real lock contention (measurable: tasks blocked >X% of attention turns on locks), *then* design quantities/windows — with data, not anticipation.

### 8.4 Workflows and action templates

Workflow = DAG of `observe`, `verify`, `task`, `wait` nodes; direct RPC nodes forbidden. Action templates define: typed params, required fresh predicates, max RPCs + wall time, dry-run requirements, desired-state/idempotency semantics, ownership of created objects, partial-failure handling, verification query + outcome window, rollback where physically possible.

### 8.5 Verification and attribution (expanded — this is the hard part)

- Every task declares a `verify` predicate over observations plus an outcome window and a freshness bound.
- Verifier answers `pass` / `fail` / `unknown`. `unknown` → re-observe; never assume either way. A verification that can't resolve within its window marks the task `failed` with class `verification/attribution`, which is honest, not a bug.
- **Attribution is best-effort and explicitly not trusted per-action.** We record intervening incidents in evidence, but a single "food improved after PLANT_RICE" is a data point, not a lesson. Lessons require context-matched repeated evidence; policy comparisons happen at the matched-trial level (§11). Per-action credit assignment is logging, not learning.
- `ui.build` success means *placement*, not shelter. Success is observed enclosure, access, temperature, use.

---

## 9. Attention and event loop

### 9.1 Reconciliation cycle

Each wake: ingest bridge events + Steward ledger → refresh only observations needed by due obligations → reconcile pending actions + verify due outcomes → update maintenance vector + blockers → deterministic emergency precedence → form eligible queue → take one bounded turn → persist → schedule next wake.

Queue = ready tasks, due verifications, blocked tasks due inspection or with changed blockers, due maintenance reviews, triggered planner requests, operator obligations. `awaiting_result` never implies re-issue.

### 9.2 Precedence and score

`operator pause → deterministic life emergency → critical deadline → overdue max-review obligation → scored ordinary work`. Score is config (versioned tunables, currently `0.35 urgency + 0.20 goal + 0.15 deadline + 0.10 unblock + 0.10 time-since-review + 0.10 utility − switch cost − lock conflict`). **These weights are unvalidated hypotheses; do not tune them before Arm B baseline exists.** Tie-break: earliest deadline, oldest attention, task ID. Min dwell prevents oscillation, never blocks emergencies.

### 9.3 Game speed

Pause for: initial landing plan, operator takeover, uncertain write reconciliation, emergencies needing a consistent snapshot. Normal speed when events are developing or model latency could miss outcomes. Superfast during calm deterministic stretches. Ultrafast only in labeled eval tracks after latency is measured. Record requested speed, actual TPS, observation age, model wait. **Operator pause, game pause, and dispatcher ownership are three independent persisted states; resuming one never resumes the others.**

### 9.4 Agent lifecycle vs. game lifecycle (new)

Clean shutdown → request game pause first, then drain/cancel pending writes, then exit. Crash → on restart, reconcile mode (§7.4). If the game wasn't paused (hard crash), treat all in-flight actions as uncertain and verify effects before any retry.

---

## 10. Decision matrices

Per v1 §10, unchanged in contract: matrix attaches to a task template; each matching row has typed predicates + explicit priority, required features + freshness, ≤4 productive options, `CONTINUE` + `ESCALATE`, candidate-binding rules, hard constraints, selector question + criteria, deterministic fallback, action-template mapping, limits/cooldown/timeout/verify, expected-outcome windows. Same-priority multi-match = validation error. Selector returns only offered IDs.

Routing: 1 productive option → dispatch by rule. 2–4 → Tier 1 (or `rules`). 0 → `ESCALATE` or capability-gap block. Missing critical fact → observe, don't ask. Emergency → deterministic or pause. Timeout/invalid → matrix fallback. High-impact irreversible → planner or human per autonomy policy.

Domain coverage and guide priors (v1 §§11–12) are **policy content, not architecture** — they live in `brain/policy/` and `brain/knowledge/rules/` as seeded content, loaded through the same validation path as everything else. The spec doesn't need to enumerate gameplay strategy; the settings examples in `settings/` already do.

### 10.1 Spatial planning (scoped down)

v1's general spatial planner (rotated/irregular/phased candidates with critical-path analysis) is deferred (§15). v1 approach:

- **Fixed layout templates** parameterized by site survey: `reuse_room`, `rectangle_open`, `mine_out_grid`, `hybrid_temp_then_durable`. Each template has known materials, pawn-hour ranges, phase order, and validation predicates (roof support, access, fire exposure heuristics).
- Phased execution `survey → reserve → clear/mine → inspect → shell/utilities → furnish → verify use`, with re-estimation after every phase and worker loss. Never place unreachable blueprints behind unmined rock.
- A general planner replaces templates only when template coverage demonstrably fails on real colonies — and it becomes a Phase 5+ work item with its own spec.

---

## 11. Execution: Steward and RimBridge

Per v1 §14, unchanged: highest sufficient altitude (`standing order → persistent policy/threshold bill → bounded order/gizmo → validated designation/zone → direct pawn job → reflective write [prohibited]`); Steward owns routine priorities/stock, standing orders own reflexes, framework owns strategic targets/posture/locks/sites/research backlog/workflows/verification; one arbiter composes a single Steward posture; only next validated research project enters Steward's queue; **dispatch desired states, not repeated commands**; query intended effect before retrying uncertain actions. Manual overrides suspend the affected owner explicitly and return ownership on clear.

---

## 12. Self-improvement

Three separate loops: execution recovery (refresh/retry/alternate offered method/block), current-plan repair (revise this colony's tasks/deps/locks/goals), reusable policy learning (propose and test for the future). **Recovery success proves nothing reusable.**

Evidence records per v1 §15.2 (revisions, features + freshness, scheduler score + competition, all candidates + exclusions + reasons, selected/executed actions, RPC results, latency/cost/ticks, expected vs. actual + intervening incidents). No outcome inference for unchosen candidates. Failure classification taxonomy per v1 §15.3.

Lesson ledger, promotion pipeline, and the ≤5% bounded auto-adaptation: per v1 §§15.4–15.6, all **Phase 7**. Nothing in Phases 0–6 depends on them. The pipeline (diagnose → scoped proposal → validation → fixtures → matched trials → held-out check → human gate → atomic activation → monitored cohort → retain/rollback) and its invariants are kept as designed — they were well-specified; they're just late.

---

## 13. Evaluation

### 13.1 Environment control

Freeze + record: game build/DLCs/mods/load order; scenario/storyteller/difficulty/tile; **full starting save hash**; policy/lesson/adapter/endpoint/code revisions; speed policy, Steward config, action budgets; assisted actions and manual interventions.

### 13.2 Arms

A: frozen upstream free-form loop. B: framework, `rules` selector only. C: B + fixed cheap selector. D: C + frozen improved policy. E (optional): trained local outcome selector. Hold everything else fixed per comparison.

### 13.3 Metrics (priority order)

1. **Integrity:** survival, original-colonist deaths, total deaths, illegal writes, unhandled emergency stalls, forced reloads, manual interventions.
2. **Maintenance:** hunger pawn-hours, unsafe temp, unprotected sleep, untreated/bleeding time, per-pawn distress, breaks, outages, spoilage.
3. **Progress:** verified capabilities in use, defensible infrastructure, incident recovery, endgame milestones.
4. **Efficiency:** model cost/game-day, calls by role, latency, actual TPS, game-days/wall-hour, writes, duplicate rate, fallback rate.
5. **Framework quality:** verified goal success, deadline misses, overdue attention, blocked duration, plan churn, repeated failures, trace completeness.

Report wealth; never optimize it.

### 13.4 Wall-clock budget (new)

There is no headless RimWorld. Measure in Phase 0: real minutes per game-day at 3× (expect ~4–8). A 60-day pilot ≈ 5–8 real hours *per run* plus stalls; a 5-arm × 3-replicate pilot ≈ 75–120 machine-hours. Budget accordingly: e.g., **~300 eval machine-hours** for the whole program, allocated mostly to short matched trials (rungs 4–7 of the ladder) and fixtures, with 60-day pilots rare and scheduled. If a phase's exit requires eval hours we don't have, the phase criterion shrinks — it doesn't get waived.

### 13.5 Statistical honesty

Matched saves control start variance; storyteller RNG still diverges runs. **N ≥ 3 matched replicates per arm for any comparison we act on**; report distributions, not point estimates. Uncertainty groups by starting-save family, never by correlated decisions within one colony. Held-out set stays locked until retirement.

### 13.6 Test ladder

Per v1 §16.4: unit tests → recorded fixtures (stale/missing data, malformed provider output) → shadow mode → short matched bootstrap trials → combined maintenance → research/production/trade/recruitment → matched combat + recovery → caravans/quests/seasons/endgame → 60-day pilots → locked held-out final.

---

## 14. Repo changes

Per v1 §17, with one correction of emphasis:

- New packages `framework/`, `providers/`, `policy/`, `domains/` as listed — but **phase-gated**: `domains/` starts with `bootstrap`, `food`, `health` (emergency reflexes) only; the rest are added at their phase, not scaffolded upfront.
- `runner.py` gets `framework` mode beside legacy modes. `roles.py` parallel specialists are disabled in framework mode (read-only advisers at most). `reflect.py` stops live brain mutation in framework/scored mode.
- `loop.py` observation gathering is refactored into standalone functions so framework packets never spin up a tool conversation.
- Config per v1 §17.3 (`controller.mode`, `autonomy`, endpoint roles, secret refs). Environment substitution for non-secret settings; backend resolver for credentials.

---

## 15. Deferred / cut list

Explicitly **not** in v1 of this system. Each requires demonstrated need + its own mini-spec to re-enter:

- General spatial planner (template layouts first, §10.1).
- Quantitative/windowed/preemptive resource reservations (exclusive categories first, §8.3).
- Lesson retrieval into planner/selector prompts (Phase 7).
- Automatic promotion of any kind, including the 5% numeric exploration budget (Phase 7+, gated).
- Caravan/world-map deep coordination beyond accept/decline + capacity checks.
- Arm E trained selector.
- Multi-colony or multi-map play.
- Anything requiring RimBridge changes — bridge changes go upstream to RimBridge; framework policy lives in Steward/Python. Bridge changes only when a required observation/action is provably impossible via current RPCs.

---

## 16. Phased plan — measurable exits, and what gets cut if we slip

| Phase | Build | Measurable exit | If blocked |
|---|---|---|---|
| **0 — baseline** | Fork pinned, tests running, obs capture, timing measured | Legacy episode reproduced; obs capture replayed offline; measured real-min/game-day at each speed | — |
| **1 — spine, shadow** | Schemas, store, registry, reconcile, goals/tasks, locks-lite, maintenance vector, attention queue. Runs beside legacy, **zero writes** | Restart-safe trace from objective→task across a forced mid-session crash; shadow runs 5 sessions with zero crashes; every maintenance metric shadow-validated vs. a labeled save | Cut domains from shadow until core is stable |
| **2 — dispatcher live** | Dispatcher, verification, idempotent writes, Steward arbitration. Domains: food + emergency reflexes only. `rules` selector | Framework runs a landing 3 game-days live; zero illegal/unowned writes; every write verified or marked failed with class | If Steward arbitration fights, drop framework posture control and run Steward stock-only |
| **3 — holistic first week** | Planner adapter + triggers; bootstrap/labor/shelter/logistics/health/defense-readiness tasks; matrix routing incl. model selector behind adapter | Matched start reaches stable week-1 maintenance; planner calls within budget; framework becomes default mode | Selector model not ready → ship `rules`, Arm C deferred |
| **4 — stable maintenance** | Seasons/preservation, power/temp, mood causes, storage/workshop logistics, production/equipment, research capability graph | 20–30 day matched trials hold all enabled domains; no hidden starvation of earlier goals | Cut to per-domain trials if combined trials exceed eval budget |
| **5 — world** | Wealth utility accounting, trade candidates, recruitment/prisoners, animals, quests/caravans w/ home-capacity locks | Explains + safely executes accept/decline, buy/sell, recruit/release, caravan on matched scenarios | Caravans deferrable entirely — least-critical domain |
| **6 — defense/endgame** | Bounded tactical overrides (post-fixture), full incident recovery, one victory path | Matched incident trials meet survival guardrails with complete lineage | Tactical overrides stay Steward-only; recovery still ships |
| **7 — learning** | Failure clustering, lesson retrieval, reviewer proposals, promotion pipeline, rollback | One real failure → scoped proposal → passes or fails declared gates; a bad proposal is rejected; rollback preserves lineage | The whole phase is optional for "plays well" — it's the B3 bet |

---

## 17. Acceptance criteria (made checkable)

Autonomous trials require all of:

**Control/safety**
- Zero game writes outside the dispatcher in any run log (audited: `actions.jsonl` writer field).
- Zero emergency responses that waited on a provider call (audit `endpoint-traffic` × emergency windows).
- Zero executions of stale/malformed/unoffered model results (fixture suite + live audit).
- Forced crash mid-write → restart reconciles before any new write (tested, not assumed).
- Operator pause blocks writes and survives restart.

**Efficiency**
- Routine pawn work: zero model calls (Steward only).
- ≥80% of attention turns resolve deterministically or via `rules`/cheap selector in stable play — *target to validate, not a reason to suppress escalation*.
- Every planner call maps to a declared trigger in the trace.

**Planning**
- Active plan spans immediate/seasonal/strategic horizons with replan triggers.
- Maintenance gates cover all nine domains with per-pawn floors.
- Non-survival work provably consumes only surplus envelopes (reservation audit).

**Reviewability** — a reviewer answers, from the dashboard/export alone: current objective; why this task has attention; which facts are fresh/stale/unknown; legal/excluded/selected options; what was dispatched; whether it worked; which lesson applied; what evidence backs a proposal. Each is a UI/report checklist item, not a vibe.

**Learning** — frozen snapshots in scored runs; held-out isolation; proposals never self-activate; promotion/rollback preserve lineage.

---

## 18. Test matrix

v1 §20's list is good — keep all 24 fixtures, grouped: *state* (already-satisfied goal, stale observation, cyclic dep), *locks* (conflicting reservations, only-cook-is-best-miner), *dispatch* (ack-but-no-effect, timeout-but-effect-exists, duplicate bill/blueprint/designation), *provider* (unoffered option, malformed JSON, no confidence, timeout, late, swap with in-flight), *domain* (inaccessible food, season-invalidated crop, unenclosed room, miner lost mid-dig, power loss, mood hidden by average, unimplemented research, wealth-without-defense, caravan strips coverage, raid aftermath), *policy* (lesson context mismatch, synthetic/held-out attempting promotion), *recovery* (crash with pending action + locks).

---

## 19. Open questions for the operator

These block specific phases, not the project — but answer them before Phase 1:

1. **Local endpoint contract.** "Laya" is unspecified. What's actually deployable locally, and does it satisfy a bounded-choice contract? Jev's `Choice`/`Score` API constrains how matrices compile. Pick the adapter target before Phase 2.
2. **Autonomy ceiling.** Which action classes require human approval even at `autonomous` (suggest: prisoner execution/release, caravan departure, irreversible construction over X resources)?
3. **Eval budget.** How many machine-hours are actually available? This sizes §13.4 and may compress the ladder.
4. **Dogfood colony vs. eval saves.** Live play and scored evaluation need different saves/seed control — confirm both exist.
5. **Kill thresholds.** Agree now on what B1/B2 falsification looks like numerically (e.g., "Arm C not > Arm B on maintenance metrics across N=9 trials") so it isn't negotiated after the fact.

---

## Appendix A — what changed from v1 and why

- **Added:** falsifiable bets; ranked risk register; concurrency model (single asyncio loop, single dispatcher task); selector skepticism with `rules` default and fixture-gate; wall-clock eval budget; schema migration + Windows fsync/torn-tail specifics; agent-vs-game lifecycle (pause on shutdown); scoped-down locks and spatial planning; contractual deferred list; measurable phase exits; open-questions list.
- **Kept:** single-writer invariant and authority table; typed-intent boundary; two model roles; flat-file layout; matrix contract; test matrix; promotion pipeline design; eval arms.
- **Moved:** domain table and guide priors → policy content (settings/brain files), not spec.
- **Softened:** "≤4 options" and attention weights marked as tunables; "80% deterministic" marked as a target to validate.

# RimPack — DS4 Revision of the Local-First Holistic RimWorld Agent Specification

**Status:** Proposed revision (v2). Supersedes `LOCAL-FIRST-HOLISTIC-AGENT-SPEC.md` where the two conflict.
**Author note:** This is the "DS4" revision. It applies two reviews to v1: (1) a skeptical pass that cuts what is unlikely to work or is not worth its complexity, and (2) a distribution pass that turns the learning plan/matrix system into a first-class, shareable, peer-improved artifact ("RimPack"). It also incorporates a fresh finding: **Laya** is confirmed as an open-weight, non-generative typed-decision model (`choice`/`score`/`noul`, calibrated probabilities, single forward pass, ~421M params, local PyTorch/MLX/CoreML inference, Hugging Face `convaiinnovations/laya`), which is a better default Tier-1 selector than a hosted API for this project.

---

## 0. Executive summary

The v2 design makes five decisions that v1 left unresolved:

1. **Distribution is the point, not an add-on.** The learning loop cannot be validated by one person's matched trials: colony outcomes are high-variance, episodes take hours, and promotion gates in v1 were practically unreachable at single-operator scale. The only realistic way to get statistical power is a community of volunteers running a standard harness. Therefore the shareable artifact, its verification, and its benchmark protocol are designed from day one, not bolted on later.
2. **Policy is code; packs are untrusted until proven.** Packs contain matrices, plans, lessons, and (in later phases) Python tools/watchers. Anything a stranger contributes must pass: schema validation → offline decision-replay fixtures → sandboxed execution → human review → staged rollout. Nothing from an untrusted pack auto-applies to a live colony.
3. **Deterministic first, always.** The default route for any decision is a code path. The selector only enters when two or more meaningful legal options remain. A "routine" colony should route ≥90% of attention turns with zero selector calls, and the selector route itself should be free (local Laya), so the system's only real cost is the sparse planner.
4. **The mutation loop is an experiment with kill criteria, not a feature.** Until a frozen controller beats a deterministic baseline on held-out starts with real episodes, "self-improvement" is a research claim. v2 ships learning behind explicit gates, with replay-first evaluation and a default of *no live mutation* in ranked play.
5. **Cut the machinery to the survival spine first.** v1's twenty-one sections described a complete ERP for a colony simulator. v2 ships: landing plan → maintenance vector → attention → matrix → dispatcher → verify → evidence. Everything else is a domain module that plugs into that spine.

---

# Part I — Skeptical review of v1 (and of the premise)

## I.1 What survives skepticism

These parts of v1 are worth keeping, largely because upstream RimAgent already proved their value:

- **RimBridge player-parity interface** and change-first observations.
- **Steward + standing orders** as the deterministic execution layer.
- **One game-write dispatcher** with idempotent desired-state writes.
- **Bounded decision matrices** as the model interface (typed option IDs, no free text).
- **Cheap/local selector** for routine choices (now concretely Laya).
- **Flat files** for knowledge and evidence: transparent, diffable, forkable — the only format that makes peer improvement possible at all.
- **Immutable, lineage-linked evidence** and refusal to infer outcomes for unchosen options.
- **Frozen policy/lesson snapshots** during scored runs.

## I.2 Where v1 was over-engineered, and what v2 cuts

| v1 item | Skeptical verdict | v2 disposition |
|---|---|---|
| 21 sections, ~60K chars of spec | The spec itself is a review burden; most of it never gets implemented | Cut to a lean spine + replaceable domain modules; this document is shorter |
| Elaborate settings registry with atomic registry swaps, proposals workspace, protected kinds | Valuable later; a large early tax | Ship a minimal registry (kind, id, revision, path, owner) in v1; the full transaction machinery only when packs land |
| Two provider roles with capability tests, adapter registry, endpoint health | Necessary but v1 made it sound like a product | Keep roles; implement only `openai_chat_completions` and `laya` adapters first; stub for tests; Jev adapter optional |
| Attention scheduler with 6-term weighted score | The weights are unknowable in advance and will be tuned by feel | Keep precedence (emergency → critical deadline → overdue review → score) but make the score a *tie-break*, not a primary mechanism; version weights with packs |
| Maintenance vector of 10 domains | Correct instinct, wrong granularity for v1 | Ship 4 hard gates (safety, health, food, shelter/temperature) + a mood/power/logistics watch list; expand after field data |
| Holistic 16-domain table | Right for the end state, wrong for the first six months | Keep as roadmap; implement landing + survival spine first |
| Strict promotion gates (95% CI excludes zero, etc.) | Honest but practically unreachable alone; creates a "never promotes anything" trap | Two-tier gates: replay gates (cheap, every PR) and episode gates (expensive, applied at pack-release cadence with community data) |
| Structured "lesson ledger" with 15+ required fields | Over-specced | Minimal lesson record: statement, context match keys, evidence refs, status, provenance; extend when the data justifies it |
| Parallel specialist streams (econ/build/guard/caretaker) | Concurrent writers were already a liability upstream | Deleted from framework mode. Specialists may become read-only *advisers* only after the dispatcher proves safe |
| Watchdog self-editing project source | Keep upstream behavior, but it is orthogonal to gameplay learning | Unchanged; it stays a separate, human-deployed code-fix channel |
| Sandbox "god mode" experiments | Useful for bridge testing, not for policy learning | Keep as an assisted dev track; never enters ranked packs |

## I.3 The learning loop is currently an unfalsified hypothesis

Upstream's own paper reports both completed colonies were lost, and claims "the slope, not the intercept" — i.e., the learning claim is not yet demonstrated. The structural reasons it may never work, and what v2 does about each:

1. **Sample size.** One colony produces thousands of *correlated* decisions, not thousands of independent trials. Pairing starts does not remove pawn/event/RNG variance. Real episodes take hours of wall time.
   → v2 moves the unit of learning evidence from "colony" to *decision replays* for cheap signal, and uses community benchmark runs for the expensive signal.
2. **Attribution.** A food increase at hour 20 is not necessarily caused by the action at hour 3. Intervening raids, labor shifts, and policy switches confound everything.
   → Evidence records store candidate causes and intervening events; lesson promotion requires context-matched repetition, not one dramatic save.
3. **Reward hacking / Goodhart.** If the scalar score rewards wealth, the learner hoards wealth and dies richer. If it rewards survival, it may game pauses or stall.
   → v2: multi-metric guardrails, no single score; assisted/dev/forced actions are recorded and excluded; the learner can never change the evaluator.
4. **Policy churn.** Mid-episode reflection edits make behavior non-stationary, so yesterday's data describes a different agent than today's.
   → v2: frozen snapshots per scored episode; mutation only between episodes in experiment mode; ranked packs change only at release boundaries.
5. **Novelty vs. repetition.** A matrix that learns only from repetition stops improving exactly when the colony enters a new situation — which is when it matters.
   → The *planner* handles novelty by proposing new rows/templates; the matrix only tunes parameters. This separation is enforced by type, not prompt.

### I.4 Kill criteria (write these down before running anything)

The following results end the corresponding feature line:

- **Kill the mutation loop** if, after ≥40 matched development episodes (20 pairs) against the deterministic baseline, the frozen improved policy shows no median improvement on the primary survival/maintenance metric with no guardrail regression. Keep the deterministic controller; keep packs read-only.
- **Kill the selector route** if local Laya (or Jev) does not beat rules-only selection on decision fixtures for a specific matrix row after 1,000 replay cases. Revert that row to deterministic.
- **Kill the planner escalation** if plan repairs do not measurably reduce repeated-failure rates in matching contexts after 10 development episodes. Fall back to human-authored plans.
- **Kill community benchmarking** if volunteer retention yields <3 independent starts per month for 3 months. Stop promising statistical claims; use the harness privately.

These are stated now, in the spec, so the project cannot quietly become a permanent research demo.

### I.5 Design principles adopted in v2

1. Code over config where a decision has an objectively correct answer.
2. Deterministic by default; model by exception; planner by rarity.
3. Everything shareable is validated, hashed, versioned, and attributable.
4. Nothing from the network executes before local proof (fixtures, sandbox, review).
5. The unit of improvement is a *pack patch* with evidence, never a live edit.
6. Metrics are declared before experiments; kill criteria before rollout.
7. Human-readable flat files are for *humans*; machine truth is schema-validated canonical records.

---

# Part II — Distribution: the RimPack artifact

## II.1 What a pack contains

A **RimPack** is a versioned, signed bundle of the "brain" layers that can be shared, forked, and peer-improved:

| Layer | Contents | Auto-applies? |
|---|---|---|
| Matrices | YAML rows: predicates, options, criteria, routing, fallback, verify | Yes, after schema + fixture validation |
| Plans / workflows | Long-term plans, goals, workflow DAGs, task templates | Yes, after schema + DAG validation |
| Parameters | Reserve targets, review cadence, attention weights, budget ceilings | Yes, within declared bounds |
| Knowledge | Markdown rules, guide-derived priors, lessons (status: prior/hypothesis) | Yes as retrieval context; never as authority |
| Evidence | Decision traces, outcomes, replay fixtures (append-only) | No — data, for training/review |
| Tools / watchers | Python | **Never auto-apply**; code review + tests + sandbox, exactly like upstream's watchdog deploy rule |

The lesson *ledger* stays local/private by default. Only sanitized, optionally-shared evidence exports upstream, never the operator's full colony log.

## II.2 Pack format and manifest

Layout:

```text
packs/<pack-id>/
  MANIFEST.yaml
  matrices/*.yaml
  plans/*.yaml
  workflows/*.yaml
  parameters/*.yaml
  knowledge/rules/*.md
  evidence/fixtures/*.json
  lessons/snapshot.yaml          # reviewed, shareable lessons only
  tools/   watchers/             # later phases; code-review gated
```

Manifest (canonical example):

```yaml
schema_version: 1
pack:
  id: rimagent.core-survival
  version: 0.3.0
  channel: stable            # dev | stable | frozen
  license: Apache-2.0
  authors: [Bvreela]
  homepage: https://github.com/Bvreela/BVRimAgent
compatibility:
  rimworld: ">=1.6,<1.7"
  mods:
    RimBridge: ">=1.0"
    RimBridgeSteward: ">=1.0"
  rimagent_code: ">=0.2.0,<0.3.0"
  selector:
    backend: laya
    model: convaiinnovations/laya
    revision: 458d7563c5cab85ff9f7f6e06cf2dd166fb697e2
    weight_hash: sha256:<...>   # optional; verified at load
requires: []                   # pack dependencies (by id/version range)
replaces: {rimagent.core-survival: "0.2.x"}
files:
  - path: matrices/food.yaml
    sha256: <hash>
  - path: knowledge/rules/food.md
    sha256: <hash>
verified_by:
  - replay-fixture-suite v1
  - schema-validation v1
signature:
  method: ed25519
  public_key_ref: https://.../<pack-id>.pub
  sig: <base64>
```

Rules:

- Content-addressed: every file hash is recorded; a pack revision is a manifest hash.
- Semantic versioning: `MAJOR` = breaking schema/compat, `MINOR` = new rows/plans, `PATCH` = fixes within same semantics.
- Pinning: an episode records the exact pack manifest hash used; an upgrade is a new episode configuration, never a live swap.
- Channel discipline: `dev` packs may change anything and are for experiment mode only; `stable` packs change only at release boundaries; `frozen` packs are what ranked episodes actually run.

## II.3 Trust, signing, and reputation

- Packs are signed; the client verifies the signature chain to a maintainer key pinned in config (like a package manager's trust-on-first-use, but with explicit key rotation).
- Trust tiers:
  - **Tier A — project-maintained:** signature from the BVRimAgent maintainer key. Auto-apply eligible after local verification.
  - **Tier B — verified contributors:** signed by contributors whose prior pack patches passed review; applied the same way as A.
  - **Tier C — anonymous:** verifiable but never auto-applied; requires explicit human "trust this author" or full review.
- Poisoned-lesson defenses: provenance required on every lesson; "supported" status requires ≥3 independent starts; a lesson that is contradicted is retained with counterevidence, never silently deleted; adversarial submissions are a known threat and the replay + staged-rollout pipeline is the mitigation, not hope.
- Reputation is per-pack-author and earned through accepted patches and benchmark results, not self-claims.

## II.4 Packs are code: sandboxing and execution rules

- Matrices/plans/workflows/parameters are **data**, validated by schema and executed by the local dispatcher only. They cannot reach RimBridge directly.
- Tools/watchers are **Python**. Adopting a pack that contains them is equivalent to adopting a dependency: the code must be reviewed, tests must pass, and execution must be sandboxed (subprocess with no bridge handle, or an allowlisted tool registry) — mirroring upstream's watchdog philosophy. v2 does not ship pack-provided Python in the first release at all.
- The selector model itself (Laya) is pinned by revision + optional weight hash; a swapped model is a new experiment configuration, and pack manifests that reference unpinned weights are rejected for ranked play.

## II.5 The mutation loop produces pack patches, not live edits

The learning flow becomes a contribution pipeline:

```text
local experiment mode (unranked, dev pack, freeze active snapshot)
  → replay + matched dev episodes
  → evidence-linked patch proposal (files + manifest bump + fixtures)
  → CI: schema, DAG, bounds, replay suite
  → maintainer/community review (PR-equivalent)
  → release as stable/frozen pack revision
  → clients fetch/verify/apply at episode boundary
  → monitored cohort → retain or yank with lineage
```

Merge conflicts are avoided structurally: stable IDs + revision lineage + content-addressed files mean two forks editing different rows do not collide; the same row edited by two forks is a *lineage fork*, resolved by evidence and review, not by git diff hunks. A `pack diff` tool renders a human-readable before/after in the dashboard.

## II.6 Registry and federation

Minimal registry for v1 of sharing (no server needed): a static index file in the repo / a well-known URL:

```yaml
# packs/index.yaml (hosted, e.g., GitHub Pages)
schema_version: 1
updated: 2026-09-22
packs:
  - id: rimagent.core-survival
    latest: 0.3.0
    channels: {stable: 0.3.0, dev: 0.4.0-dev.2, frozen: 0.2.7}
    url: https://example.org/packs/rimagent.core-survival/0.3.0.tar.gz
    manifest_sha256: <hash>
  - id: community.hardcore-ice-sheet
    latest: 0.1.1
    channels: {stable: 0.1.1}
    url: https://example.org/packs/community.hardcore-ice-sheet/0.1.1.tar.gz
    manifest_sha256: <hash>
```

Client commands (later, a CLI): `pack list`, `pack fetch <id>@<range>`, `pack verify`, `pack diff`, `pack pin`, `pack submit <proposal-dir>`. Federation means anyone can host an index; the client's default is the project index, and users choose. No central authority beyond the maintainer key for Tier A.

**Why this matters for peer improvement:** a fork is just a pack. A contributor's entire improvement is their pack patch with replay fixtures attached. The community reviews patches, not personality.

## II.7 Offline decision-replay harness (the CI backbone)

Full RimWorld episodes cannot run in CI. The cheap, *sufficient* check is replaying recorded decisions:

- **Decision replay:** take a saved `(observation features, task, matrix revision, candidates, selected option, outcome window)` record; re-run the pack's routing + selector logic; assert the produced decision equals the recorded one (or is a permitted equivalent under the new revision), and that legality/freshness rules still hold.
- **Plan replay:** take a recorded plan; re-validate schema, DAG, references, bounds, and that no earlier goal is orphaned.
- **Trace replay:** take a recorded failure packet; assert the new pack changes the diagnosis path or prevents the error class in the fixture set.

Fixture format (one case):

```json
{
  "fixture_id": "fix.food.cold-snap-crop-choice-001",
  "pack": "rimagent.core-survival@0.3.0",
  "matrix": "matrix.food.planting@2",
  "task": "task.maintain_food_production",
  "features": {
    "days_until_shortage": 9,
    "growing_season_remaining": 24,
    "freeze_in_days": 12,
    "fertility_class": "good",
    "grower_capacity_class": "adequate"
  },
  "candidates": ["PLANT_RICE", "PLANT_CORN", "CONTINUE", "ESCALATE"],
  "recorded_choice": "PLANT_RICE",
  "outcome_window": {"food_days_at_14d": "improved_or_neutral"},
  "source_trace_ref": "runs/ep-0012/decisions/decision.food.0042.jsonl"
}
```

Every accepted pack patch must pass the pack's fixture suite plus the project's shared regression suite. This is what makes peer improvement *reviewable at scale*: a contributor cannot claim a fix without a fixture that demonstrates it.

## II.8 Community benchmark protocol (volunteers)

Goal: honest, comparable improvement data across many machines, without a server farm and without trusting anyone's self-report.

- **Standard start saves:** a small set of hash-pinned starting saves (Crashlanded, fixed seed families, recorded difficulty/DLC/mod list). RimWorld itself is not redistributed; volunteers run their own licensed copy (the same deal as every mod community).
- **Harness:** a `bench` command runs a declared controller (pack + selector + planner config) on a save for a declared horizon, records the result envelope, and submits only the result manifest + sanitized metrics + hashes.
- **Anti-cheat / integrity:**
  - every run records `assisted` flags (dev.* calls), speed/pause policy, manual interventions, and config hashes;
  - results with assisted flags, forced reloads, or unrecorded interventions are rejected or labeled;
  - a run nonce and a canonical metric function prevent replay attacks on results;
  - seeds and save hashes are checked against the published set.
- **Statistical honesty rules:** grouped by start family; paired comparisons only where the volunteer ran both arms on the same machine/save; predeclared sample sizes or sequential stopping; no cherry-picked best-of-N runs.
- **Leaderboard** is per (pack, save family, difficulty) with confidence intervals, and explicitly warns that small-N leads are not conclusions. Results feed *release decisions* (which pack patch promotes) and, eventually, the learner — only through the pack pipeline.

## II.9 Privacy, secrets, and sanitization

- Nothing shared contains: secrets, operator messages, full notebooks, or raw personal data.
- Evidence exports strip: file paths, machine identifiers, API keys, and any text the operator has marked private.
- Lessons share statements and context-match keys, not the underlying colony narrative.
- Packs never embed credentials; selector auth stays in local config.
- Consent: operator opts into sharing benchmark results and evidence; default is local-only.

## II.10 Licensing and attribution

- This repo's artifacts: Apache-2.0 (per existing LICENSE). Upstream RimAgent/RimBridge: MIT (attribution preserved). RimWorld: © Ludeon Studios, never redistributed.
- Laya weights: Apache-2.0 (per model card; verify per checkpoint); pinned revisions recorded in the manifest.
- Derived lessons/packs must carry provenance chains (which upstream pack/lesson each row extends). This keeps the fork economy honest: improvements flow back, and attribution is automatic.

---

# Part III — The DS4 architecture (lean revision)

## III.1 Control tiers and routing

Unchanged in spirit from v1, tightened in default behavior:

- **Tier 0 — deterministic:** Steward, standing orders, validators, arithmetic, workflow cursors, emergency reflexes, verification.
- **Tier 1 — local selector:** Laya (pinned revision) choosing among validated options. Zero marginal cost, ~5–40 ms, calibrated probabilities. Optional hosted Jev adapter for comparison.
- **Tier 2 — planner:** sparse strong-model calls for planning/repair/proposals.

Routing table (the actual decision procedure):

| Condition | Route |
|---|---|
| Emergency invariant | Tier 0, immediately; never wait on a model |
| One legal productive option | Tier 0 |
| No legal option | observe → escalate → block with capability gap |
| Missing/unsafe/unknown critical fact | Tier 0 observe/reconcile |
| Task is pure observe/verify | Tier 0 |
| Desired state already holds | Tier 0, mark satisfied, no write |
| Selector unavailable/timeout/invalid | matrix fallback (Tier 0) |
| Two+ meaningful options, known matrix | Tier 1 (Laya) |
| Novel situation / plan invalidated / repeated failure | Tier 2 (planner), bounded |
| Irreversible, high-impact, or human-owned | human review per autonomy policy |

**Tier 1 packet size constraint:** Laya's context is ~512–1024 tokens. Every matrix packet must fit that budget: named facts, ≤4 options, one task intent, no prose dumps. If the packet cannot fit, the feature extraction is wrong — reduce it, don't grow the model. This is a feature, not a bug: it forces the discipline v1 already wanted ("send only relevant observations").

## III.2 Core objects and file formats

- **Policy data (matrices, plans, workflows, parameters):** schema-validated YAML, canonicalized on load (no anchors/aliases; a restricted subset; unknown keys rejected). Human-readable, diffable, forkable — but the machine never *parses* loose YAML; it validates against JSON Schema first and refuses anything invalid.
- **Knowledge and rules:** Markdown with structured frontmatter (name, description, tags, context keys, evidence status). Human-edited, model-retrieved.
- **Evidence and traces:** append-only JSONL with stable IDs and revision links.
- **State (episode, goals, tasks, reservations, cursors):** JSON files, atomic-replace writes, rebuilt from files on restart.
- **Lessons:** minimal YAML records (statement, context keys, status, provenance, evidence refs, counterevidence) in a private ledger + a shareable snapshot.

Stable ID discipline: every row, plan, goal, task instance, decision, and outcome gets `id@revision`; everything references revisions, never "current file."

## III.3 Spine: reconcile → attend → route → dispatch → verify → evidence

1. **Reconcile:** ingest events, refresh due observations, reconcile pending writes, update maintenance gates.
2. **Attend:** precedence first (emergency → critical deadline → overdue review); score only breaks ties among equals; versioned weights travel in packs.
3. **Route:** the table in III.1.
4. **Dispatch:** one dispatcher, desired-state writes, idempotency keys, bounded RPC counts, ownership metadata.
5. **Verify:** freshness-limited verification; tasks succeed only via verifier.
6. **Evidence:** append immutable decision/outcome records; create failure packets; emit lesson candidates to the private ledger.

## III.4 Hard maintenance gates (v2 minimum)

| Gate | Fail condition | Response |
|---|---|---|
| Safety | active threat/bleeding-out/fire with unresolved owner | deterministic response or pause |
| Health | treatment delay or infection risk exceeding threshold | medical workflow preempts ordinary work |
| Food | accessible food below target or harvest forecast below need | food recovery preempts discretionary work |
| Shelter/temperature | unprotected sleep, unsafe temperature, or enclosure failure | shelter workflow preempts discretionary work |
| Watch list | mood break risk per pawn, power margin, hauling/storage pressure | scheduled review; escalation on threshold |

Later packs add defense-readiness, production, wealth-pressure, and world-objective gates as rows, not as new machinery.

## III.5 Holistic spine implementation order

1. **Landing plan** (pause, assess, stage: site, roles, equipment, crops, stockpile, first shelter phase, initial policies).
2. **Survival spine** (food + shelter/temperature + health + safety) — the v1 "first-week" slice, kept.
3. **Logistics and labor** (storage zones, hauling pressure, posture, one-pawn exceptions).
4. **Power and production** (generation/storage margin, bills, clothing/equipment).
5. **Mood** (per-pawn causes, recreation, rooms).
6. **Research** (capability graph → useful unlock in use).
7. **Wealth/trade/recruitment/animals** (surplus-driven).
8. **Defense posture + incident recovery** (deterministic reflexes from day 1; matrix recommendations in shadow until incident fixtures pass).
9. **World: caravans/quests/endgame** (operator-selected).

Each step reuses the same spine; nothing new is invented per domain except predicates, features, candidates, templates, and verifiers.

## III.6 Cost model and budgets

- Selector: free (Laya, local) — the dominant cost disappears.
- Planner: the only paid inference. Cap it hard:
  - initial budget: ≤1 call per game day, ≤30 per episode, ≤2 repair attempts per operation;
  - every planner call must match a declared trigger (III.1) or it is a bug;
  - packet budget: ≤4K input tokens per plan call initially; measured and lowered.
- Episodes: record actual TPS, game-days/wall-hour, observation age, missed-event count, writes per day, selector vs deterministic vs planner call counts.

## III.7 Learning v2 (gated, replay-first, distributable)

- **Modes:** `experiment` (dev pack, live mutation allowed, unranked) | `review` (proposals only) | `ranked` (frozen pack, no mutation).
- **Promotion gates:**
  - *Replay gate (every patch):* schema + DAG + bounds + shared fixture suite green.
  - *Dev-episode gate (per release):* matched dev episodes, declared primary metric + guardrails.
  - *Community gate (per stable release):* volunteer benchmark results per pack, statistics per II.8.
  - *Yank rule:* any execution-contract violation or guardrail regression disables the pack immediately; outcome regression is assessed on a cohort before rollback.
- **What may mutate locally in experiment mode:** parameters within declared bounds, matrix criteria wording/thresholds, plan/row instances. Never: evaluator, hard constraints, schemas, verifier semantics, or the dispatcher.
- **What may be auto-applied after replay proof only:** bounded numeric parameter patches, e.g., a stock target or review interval, within the declared safe interval and exploration budget (≤5% of eligible low-risk choices).

---

# Part IV — Implementation roadmap v2

| Phase | Deliverable | Exit criterion |
|---|---|---|
| 0 | Fork pinned to upstream; Windows build/launch verified; legacy baseline captured | Reproducible baseline + environment manifest |
| 1 | Spine: schemas, minimal registry, flat-file store, recovery, precedence scheduler, maintenance gates, dispatcher, verifier | Restart-safe trace objective→task→decision→outcome; zero game writes in shadow |
| 2 | Tier 1: Laya adapter (pinned), matrix validation, candidate binding, routing table, fallback; stub + Jev optional | Endpoints swappable; selector cannot return/execute unoffered actions |
| 3 | Landing plan + survival spine (food, shelter/temp, health, safety) with deterministic first-week | Matched first-week runs beat legacy free-form on maintenance metrics with fewer planner calls |
| 4 | Logistics/labor, power/production, mood, research in spine | 20–30 day matched trials hold all enabled gates |
| 5 | **Pack v0.1 (read-only):** pack format, manifest, verify, pin, fetch from static index; replay harness + fixture suite; pack diff | A contributor can download, verify, pin, and replay-test a stable pack; no pack code executes |
| 6 | **Contribution pipeline:** proposal dir, CI replay gates, PR-equivalent review flow, pack patch promotion, yank | One real repeated failure → fixture → patch → reviewed release; a bad patch is rejected |
| 7 | **Volunteer benchmark:** `bench` command, start-save set, result manifest, anti-cheat, leaderboard | ≥3 independent starts per month sustained; statistics honest per II.8 |
| 8 | Wealth/trade/recruitment/animals; defense posture shadow→incident fixtures; caravans/quests/endgame | Holistic ranked episodes at 60 days; guardrails hold; costs tracked |
| 9 | Learned parameter autopromotion (bounded, replay-proven) | Promotion history + rollbacks visible; kill criteria enforced |

Phases 5–7 are the distribution core and are *not optional stretch goals*: they are how the learning loop gets evidence at all.

---

# Part V — Explicit cuts in v2

We will not build, in this revision:

- The full v1 settings registry transaction machinery (proposal workspace, atomic registry swap, protected-kind diffs) until pack v0.1 exists and demands it.
- Parallel specialist write streams in framework mode.
- Any pack-provided Python execution in the first release (tools/watchers arrive later, code-review + sandbox gated).
- A hosted federation server or marketplace. A static index + signed tarballs is enough for v1; the protocol is designed so a marketplace could be added without changing clients.
- Fine-tuning or training any selector on colony data (Laya weights are used as published; Jev has no customer fine-tuning per its docs). A downstream interpretable outcome model remains a *later, separate* experiment (v1's Stage B), gated by replay data volume.
- Reinforcement learning, bandits beyond the bounded parameter case, or any exploration during emergencies/combat/medical/food-critical states.
- Sending full transcripts, notebooks, or raw saves to any model or registry.
- A new generic bridge/RimBridge fork unless a required observation is impossible through existing RPCs (then contribute upstream first).

---

# Part VI — Open questions and unknowns

1. **Laya quality on RimWorld matrices.** Its calibrated probabilities are for its decision tasks, not game success. Measure: does Laya beat the rules fallback per matrix row on 1,000+ replay cases before any row depends on it?
2. **Planner model choice.** The planner still needs a strong generative model; which local/remote model, and at what cost, is unresolved. Budget first, then benchmark on plan proposals, not on vibes.
3. **Jev adapter.** Jev remains a candidate hosted alternative for the selector role; its confidence semantics differ (distribution-derived). Keep the adapter contract such that switching is configuration, and run the same replay suites.
4. **Volunteer viability.** Will anyone run the harness? The benchmark protocol must be one command and must respect machines that cannot run the game at speed. If volunteer numbers fail, the kill criteria in I.4 apply.
5. **Pack governance.** Who is a maintainer? Key rotation, fork naming, and dispute resolution are social questions the protocol cannot fully solve; v2 defers to the project's maintainer key and documented contributor rules.
6. **RimWorld version drift.** Packs declare compatibility; when RimWorld or RimBridge updates, packs must be re-verified. Expect churn; the manifest hash discipline is what keeps it honest.
7. **Determinism ceiling.** Some "decisions" are really just policy (e.g., target stocks); the matrix may be overkill. Measure deterministic-first routing share; if it exceeds ~95% of turns, ask whether the remaining 5% is worth a model at all — the answer may be "yes, and it is nearly free with Laya."

---

## Conclusion

v1 asked: *how do we make an agent that plans, chooses, and learns?* v2 asks the harder question: *how do we make an agent whose improvements can be shared, verified, and trusted by strangers?* The answer is a pack pipeline (data-validated, replay-proven, sandboxed, signed, pinned), a sparse strong planner, a free local selector, and a deterministic spine — with explicit kill criteria so the project fails fast and honestly if the learning premise does not hold. Distribution is not the final feature; it is the evidence engine for everything else.